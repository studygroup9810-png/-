#!/bin/sh
# Consistent backup of the database + uploads (run from cron). Usage: deploy/backup.sh /opt/friendspace/data /backups
set -e
DATA=${1:-./data}; OUT=${2:-./backups}; mkdir -p "$OUT"; STAMP=$(date +%Y%m%d-%H%M%S)
node -e "const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync('$DATA/friendspace.db');d.exec(\"VACUUM INTO '$OUT/friendspace-$STAMP.db'\")"
tar -czf "$OUT/uploads-$STAMP.tar.gz" -C "$DATA" uploads
echo "backup written to $OUT ($STAMP)"
