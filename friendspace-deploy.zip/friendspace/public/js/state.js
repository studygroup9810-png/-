import { t } from './i18n.js';

export const S = {
  me: null, convs: new Map(), friends: [], incoming: [], outgoing: [], blocked: [], online: new Set(), stickers: [], limits: {},
  tab: 'chats', filter: 'all', activeId: null, panel: null, ws: null, wsUp: false, typing: new Map(),
  users: new Map(), meeting: true,
};
export const hooks = {}; // filled by app.js: open, refreshSide, renderChat, ...

export class ApiError extends Error { constructor(code, status, data) { super(code); this.code = code; this.status = status; this.data = data || {}; } }
export async function api(method, url, body, opts = {}) {
  const headers = { 'X-Requested-With': 'FriendSpace' };
  let payload;
  if (opts.raw) { payload = body; headers['Content-Type'] = 'application/octet-stream'; }
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  let r;
  try { r = await fetch(url, { method, headers, body: payload, credentials: 'same-origin' }); }
  catch { throw new ApiError('network', 0); }
  let data = null;
  try { data = await r.json(); } catch {}
  if (!r.ok) {
    if (r.status === 401 && !url.startsWith('/api/auth/')) hooks.sessionLost?.();
    if (data?.error === 'account_suspended') hooks.onSuspended?.();
    if (data?.error === 'content_violation') hooks.onViolation?.(data);
    throw new ApiError(data?.error || 'server_error', r.status, data);
  }
  return data;
}
export const errText = (e) => (e instanceof ApiError ? t('e.' + e.code) : String(e?.message || e));

export function cacheUser(u) { if (u?.id) S.users.set(u.id, { ...S.users.get(u.id), ...u }); }
export function userById(id) { if (S.me && id === S.me.id) return S.me; return S.users.get(id) || null; }
export function convTitle(c) { return c.type === 'dm' ? (c.peer?.display_name || '—') : c.name; }
export function convAvatarSrc(c) { return c.type === 'dm' ? c.peer : { id: c.id, display_name: c.name, avatar_file: c.avatar_file }; }
export function upsertConv(c) {
  S.convs.set(c.id, c);
  if (c.peer) cacheUser(c.peer);
}
export function totalUnread() { let n = 0; for (const c of S.convs.values()) if (!c.my.muted && !c.my.archived) n += c.unread; return n; }
export function sortedConvs() {
  return [...S.convs.values()].sort((a, b) => (b.my.pinned - a.my.pinned) || (b.last_at - a.last_at));
}
export function previewText(m, c) {
  if (!m) return t('no_messages');
  if (m.deleted) return t('msg_deleted');
  let s;
  switch (m.kind) {
    case 'sticker': s = m.body; break;
    case 'file': s = '📎 ' + (m.body || t('attachment')); break;
    case 'meeting': s = '🎥 ' + t('meeting_link'); break;
    case 'system': s = sysText(m.body); break;
    default: s = m.body;
  }
  s = String(s).replace(/\s+/g, ' ');
  if (m.kind !== 'system' && m.sender_id === S.me.id) s = t('you') + ': ' + s;
  else if (m.kind !== 'system' && c?.type === 'group') { const u = userById(m.sender_id); if (u) s = u.display_name.split(' ')[0] + ': ' + s; }
  return s;
}
export function sysText(body) {
  let d; try { d = JSON.parse(body); } catch { return ''; }
  return t('sys.' + d.e, { n: d.n || '', by: d.by || '', name: d.name || '' });
}

export async function uploadFile(file, { purpose = 'attachment', conv } = {}) {
  const max = purpose === 'avatar' ? S.limits.avatar : S.limits.upload;
  if (file.size > max) throw new ApiError('too_large', 413);
  const qs = new URLSearchParams({ name: file.name, purpose });
  if (conv) qs.set('conv', conv);
  return (await api('POST', '/api/upload?' + qs, file, { raw: true })).file;
}
