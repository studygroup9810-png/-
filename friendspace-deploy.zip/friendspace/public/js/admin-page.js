// Standalone admin console (/admin.html). Same session + same API as the chat app; all text is set via textContent.
const root = document.getElementById('root');
let me = null, section = 'overview';
const api = async (method, url, body) => {
  const r = await fetch(url, { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'FriendSpace', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'error'), { code: d.error, status: r.status });
  return d;
};
const h = (tag, props, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) { if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (v === true) e.setAttribute(k, ''); else if (v !== false && v != null) e.setAttribute(k, v); }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return e;
};
const date = (ms) => ms ? new Date(ms).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const ERR = { invalid_credentials: 'بيانات الدخول غير صحيحة', too_many_attempts: 'محاولات كثيرة، انتظر 15 دقيقة', forbidden: 'ليست لديك صلاحية', network: 'تعذّر الاتصال', invalid: 'قيمة غير صالحة', account_suspended: 'الحساب موقوف' };
const errMsg = (e) => ERR[e.code] || e.code || 'حدث خطأ';
const btn = (label, onclick, cls = '') => h('button', { class: 'btn ' + cls, type: 'button', onclick }, label);
const ROLE = { admin: 'مدير', moderator: 'مشرف', user: 'مستخدم' };
const SECTIONS = [['overview', 'نظرة عامة', 0], ['users', 'المستخدمون', 0], ['appeals', 'الاعتراضات', 0], ['violations', 'المخالفات', 0], ['reports', 'البلاغات', 0], ['announce', 'إعلان للجميع', 1], ['settings', 'الإعدادات', 1], ['audit', 'سجل العمليات', 1], ['export', 'تصدير البيانات', 1]];

function loginView(msg) {
  const id = h('input', { class: 'input', name: 'id', autocomplete: 'username', required: true, 'aria-label': 'البريد أو اسم المستخدم', placeholder: 'البريد أو اسم المستخدم' });
  const pw = h('input', { class: 'input', type: 'password', name: 'pw', autocomplete: 'current-password', required: true, 'aria-label': 'كلمة المرور', placeholder: 'كلمة المرور' });
  const err = h('p', { class: 'err', role: 'alert' }, msg || '');
  root.replaceChildren(h('form', { class: 'login', onsubmit: async (e) => {
    e.preventDefault(); err.textContent = '';
    try { await api('POST', '/api/auth/login', { identifier: id.value, password: pw.value }); await boot(); } catch (x) { err.textContent = errMsg(x); }
  } }, h('h1', null, 'لوحة المدير'), h('p', { class: 'muted' }, 'للمديرين والمشرفين فقط'), id, pw, err, h('button', { class: 'btn primary', type: 'submit' }, 'دخول'), h('a', { href: '/' }, 'العودة إلى الدردشة')));
}
function shell() {
  const isAdmin = me.role === 'admin';
  const nav = h('nav', { 'aria-label': 'الأقسام' }, h('h1', null, 'FriendSpace · الإدارة'),
    SECTIONS.filter((s) => isAdmin || !s[2]).map(([k, l]) => h('button', { type: 'button', 'aria-current': k === section ? 'page' : null, onclick: () => { section = k; shell(); } }, l)),
    h('span', { class: 'sp' }), h('a', { href: '/', class: 'btn', style: 'text-align:center;text-decoration:none' }, 'فتح الدردشة'),
    btn('خروج', async () => { try { await api('POST', '/api/auth/logout', {}); } catch {} loginView(); }));
  const main = h('main', null, h('h2', null, SECTIONS.find((s) => s[0] === section)[1]));
  root.replaceChildren(h('div', { class: 'shell' }, nav, main));
  document.title = 'FriendSpace — ' + SECTIONS.find((s) => s[0] === section)[1];
  VIEWS[section](main).catch((e) => main.append(h('p', { class: 'err' }, errMsg(e))));
}
const table = (heads, rows) => h('div', { class: 'wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, heads.map((x) => h('th', null, x)))), h('tbody', null, rows.map((r) => h('tr', null, r.map((c) => h('td', null, c)))))));
const empty = (t) => h('p', { class: 'muted' }, t);

const VIEWS = {
  async overview(m) {
    const s = await api('GET', '/api/admin/stats');
    const L = [['users', 'مستخدمون'], ['online', 'متصلون الآن'], ['suspended', 'موقوفون'], ['disabled', 'معطّلون'], ['open_appeals', 'اعتراضات بانتظار المراجعة'], ['open_reports', 'بلاغات مفتوحة'], ['groups', 'مجموعات'], ['messages', 'رسائل']];
    m.append(h('div', { class: 'stats' }, L.map(([k, l]) => h('div', { class: 'stat' + ((k === 'open_appeals' || k === 'open_reports') && s[k] ? ' alert' : '') }, h('b', null, s[k]), h('span', null, l)))),
      h('p', { class: 'muted' }, 'خصوصية: لا تعرض هذه اللوحة محتوى المحادثات الخاصة. ترى فقط الرسائل التي أُبلغ عنها أو التي منعها نظام الإشراف.'));
  },
  async users(m) {
    const q = h('input', { class: 'input', type: 'search', placeholder: 'بحث بالاسم أو البريد', 'aria-label': 'بحث' });
    const box = h('div');
    const load = async () => {
      const { users } = await api('GET', '/api/admin/users?q=' + encodeURIComponent(q.value));
      const act = async (fn) => { try { await fn(); await load(); } catch (e) { alert(errMsg(e)); } };
      box.replaceChildren(users.length ? table(['المستخدم', 'الدور', 'الحالة', 'آخر ظهور', 'إجراءات'], users.map((u) => [
        h('div', null, h('b', null, u.display_name), h('div', { class: 'muted' }, '@' + u.username + (u.email ? ' · ' + u.email : ''))),
        me.role === 'admin' && u.id !== me.id ? h('select', { class: 'input', 'aria-label': 'الدور', onchange: (e) => act(() => api('PATCH', '/api/admin/users/' + u.id, { role: e.target.value })) }, Object.entries(ROLE).map(([k, l]) => h('option', { value: k, selected: k === u.role }, l))) : ROLE[u.role],
        u.disabled ? h('span', { class: 'tag bad' }, 'معطّل') : u.suspended_until ? h('span', { class: 'tag bad' }, 'موقوف حتى ' + date(u.suspended_until)) : h('span', { class: 'tag' }, u.online ? 'متصل' : 'نشط'),
        date(u.last_seen),
        u.id === me.id ? '—' : h('div', { class: 'row' },
          btn(u.disabled ? 'تفعيل' : 'تعطيل', () => confirm((u.disabled ? 'تفعيل' : 'تعطيل') + ' الحساب؟') && act(() => api('PATCH', '/api/admin/users/' + u.id, { disabled: !u.disabled })), 'sm'),
          u.suspended_until ? btn('رفع الإيقاف', () => act(() => api('POST', `/api/admin/users/${u.id}/lift-suspension`, {})), 'sm') : null,
          me.role === 'admin' ? btn('رابط استعادة', async () => { try { const r = await api('POST', `/api/admin/users/${u.id}/reset-link`, {}); prompt('انسخ الرابط وأرسله للمستخدم (صالح ساعة):', r.link); } catch (e) { alert(errMsg(e)); } }, 'sm') : null,
          me.role === 'admin' ? btn('حذف', () => confirm('حذف الحساب نهائيًا؟ لا يمكن التراجع.') && act(() => api('DELETE', '/api/admin/users/' + u.id)), 'sm danger') : null),
      ])) : empty('لا نتائج'));
    };
    q.addEventListener('input', (() => { let t; return () => { clearTimeout(t); t = setTimeout(load, 250); }; })());
    m.append(q, box); await load();
  },
  async appeals(m) {
    const { appeals } = await api('GET', '/api/admin/appeals?status=open');
    if (!appeals.length) return m.append(empty('لا توجد اعتراضات بانتظار المراجعة.'));
    for (const a of appeals) {
      const reply = h('input', { class: 'input', placeholder: 'ردّك على المستخدم (اختياري)', maxlength: 500, 'aria-label': 'الرد' });
      const decide = async (d) => { try { await api('PATCH', '/api/admin/appeals/' + a.id, { decision: d, response: reply.value }); shell(); } catch (e) { alert(errMsg(e)); } };
      m.append(h('div', { class: 'card' }, h('h3', null, `${a.display_name} (@${a.username}) — ${date(a.created_at)}`),
        h('div', null, h('span', { class: 'muted' }, 'الرسالة المخالفة: '), h('div', { class: 'quote' }, a.vtext || '—')),
        h('div', { class: 'muted' }, `التصنيف: ${a.category} · الموضع: ${a.context} · الإيقاف حتى ${date(a.suspended_until)}`),
        h('div', null, h('span', { class: 'muted' }, 'اعتراض المستخدم: '), h('div', { class: 'quote' }, a.text)), reply,
        h('div', { class: 'row' }, btn('قبول ورفع الإيقاف', () => decide('accept'), 'primary'), btn('رفض الاعتراض', () => decide('reject'), 'danger'))));
    }
  },
  async violations(m) {
    const { violations: v } = await api('GET', '/api/admin/violations');
    m.append(v.length ? table(['المستخدم', 'التاريخ', 'التصنيف', 'الموضع', 'النص', 'الحالة'], v.map((x) => [`${x.display_name} (@${x.username})`, date(x.created_at), x.category, x.context, h('div', { class: 'quote' }, x.text || ''), x.status + (x.appeal_status ? ' · اعتراض: ' + x.appeal_status : '')])) : empty('لا توجد مخالفات.'));
  },
  async reports(m) {
    const { reports } = await api('GET', '/api/admin/reports?status=open');
    if (!reports.length) return m.append(empty('لا توجد بلاغات مفتوحة.'));
    for (const r of reports) {
      const done = async (status, action) => { try { await api('PATCH', '/api/admin/reports/' + r.id, { status, action }); shell(); } catch (e) { alert(errMsg(e)); } };
      m.append(h('div', { class: 'card' }, h('h3', null, `بلاغ من @${r.reporter_name} — ${date(r.created_at)}`), h('div', { class: 'muted' }, 'السبب: ' + r.reason),
        r.snapshot.body ? h('div', { class: 'quote' }, r.snapshot.body) : h('div', null, '@' + (r.snapshot.username || '')),
        h('div', { class: 'row' }, r.target_type === 'message' ? btn('حذف الرسالة', () => done('resolved', 'delete_message'), 'sm') : null, btn('تعطيل المستخدم', () => confirm('تعطيل الحساب؟') && done('resolved', 'disable_user'), 'sm danger'), btn('تم', () => done('resolved'), 'sm primary'), btn('تجاهل', () => done('dismissed'), 'sm'))));
    }
  },
  async announce(m) {
    const body = h('textarea', { class: 'input', rows: 3, maxlength: 500, 'aria-label': 'نص الإعلان', placeholder: 'نص الإعلان (حتى 500 حرف)' });
    const days = h('select', { class: 'input', 'aria-label': 'مدة الظهور', style: 'width:auto' }, [1, 3, 7, 14, 30].map((d) => h('option', { value: d, selected: d === 3 }, d + ' يوم')));
    const list = h('div');
    const load = async () => {
      const { announcements } = await api('GET', '/api/admin/announcements');
      list.replaceChildren(announcements.length ? table(['الإعلان', 'نُشر', 'ينتهي', ''], announcements.map((a) => [a.body, date(a.created_at), a.expires_at > Date.now() ? date(a.expires_at) : 'منتهٍ', a.expires_at > Date.now() ? btn('إزالة', async () => { await api('DELETE', '/api/admin/announcements/' + a.id); load(); }, 'sm danger') : ''])) : empty('لا إعلانات سابقة.'));
    };
    m.append(h('div', { class: 'card' }, h('p', { class: 'muted' }, 'يظهر الإعلان فورًا لكل المتصلين، ولمن يدخل لاحقًا خلال مدة الظهور.'), body, h('div', { class: 'row' }, days, btn('نشر الإعلان', async () => { try { await api('POST', '/api/admin/announcements', { body: body.value, days: +days.value }); body.value = ''; load(); } catch (e) { alert(errMsg(e)); } }, 'primary'))), list);
    await load();
  },
  async settings(m) {
    const s = await api('GET', '/api/admin/settings');
    const save = async (patch) => { try { await api('PATCH', '/api/admin/settings', patch); shell(); } catch (e) { alert(errMsg(e)); } };
    const days = h('input', { class: 'input', type: 'number', min: 1, max: 90, value: s.suspend_days, style: 'width:100px', 'aria-label': 'مدة الإيقاف بالأيام' });
    m.append(h('div', { class: 'card' }, h('h3', null, 'نظام مكافحة الشتائم'), h('p', { class: 'muted' }, 'الحالة: ' + (s.moderation === 'suspend' ? 'مفعّل' : 'متوقف')), h('div', { class: 'row' }, btn(s.moderation === 'suspend' ? 'إيقاف النظام' : 'تفعيل النظام', () => save({ moderation: s.moderation === 'suspend' ? 'off' : 'suspend' }), s.moderation === 'suspend' ? 'danger' : 'primary')),
      h('div', { class: 'row' }, h('label', null, 'مدة الإيقاف عند المخالفة (أيام): '), days, btn('حفظ', () => save({ suspend_days: +days.value })))),
      h('div', { class: 'card' }, h('h3', null, 'التسجيل'), h('p', { class: 'muted' }, 'الحالة: ' + (s.registration_open ? 'مفتوح' : 'مغلق')), h('div', { class: 'row' }, btn(s.registration_open ? 'إغلاق التسجيل' : 'فتح التسجيل', () => save({ registration_open: !s.registration_open })))),
      h('p', { class: 'muted' }, 'تُحفظ هذه الإعدادات وتتفوق على متغيرات البيئة بعد إعادة التشغيل.'));
  },
  async audit(m) {
    const { audit } = await api('GET', '/api/admin/audit');
    m.append(table(['الوقت', 'المنفّذ', 'العملية', 'الهدف', 'تفاصيل'], audit.map((a) => [date(a.created_at), a.actor_name || 'النظام', a.action, a.target || '', a.detail || ''])));
  },
  async export(m) {
    m.append(h('div', { class: 'card' }, h('p', null, 'ينزّل ملف JSON فيه الحسابات (بالبريد) والمخالفات والاعتراضات وسجل العمليات. لا يتضمن الرسائل أو الملفات.'), h('a', { class: 'btn primary', href: '/api/admin/export', download: 'friendspace-export.json', style: 'text-decoration:none;width:max-content' }, 'تنزيل التصدير')));
  },
};

async function boot() {
  try { const r = await api('GET', '/api/me'); me = r.user; } catch { return loginView(); }
  if (!['admin', 'moderator'].includes(me.role)) { try { await api('POST', '/api/auth/logout', {}); } catch {} return loginView('هذا الحساب ليس مديرًا ولا مشرفًا.'); }
  if (!SECTIONS.some((s) => s[0] === section && (me.role === 'admin' || !s[2]))) section = 'overview';
  shell();
}
boot();
