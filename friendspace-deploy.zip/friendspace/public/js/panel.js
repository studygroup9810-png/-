import { h, $, icon, avatar, iconBtn, btn, clear, menu, toast, confirmBox, modal, fmtSize, fmtDateTime, linkify } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks, convTitle, convAvatarSrc, upsertConv, cacheUser } from './state.js';
import { C, patchMe, startReply, jumpTo } from './chat.js';
import { msgEl } from './msg.js';
import { addMembersDialog, reportDialog } from './dialogs.js';
import { uploadFile } from './state.js';

let thread = null; // { root, msgs, listEl }
const aside = () => $('#info');

export function closePanel(silent) {
  S.panel = null; thread = null; document.body.classList.remove('show-panel');
  if (aside()) clear(aside());
}
export function togglePanel(kind) {
  if (S.panel === kind && kind === 'info') { closePanel(); return; }
  S.panel = kind; document.body.classList.add('show-panel');
  if (kind === 'info') renderInfo();
}
export async function refreshPanel() { if (S.panel === 'info') renderInfo(); }

const head = (title) => h('header', { class: 'panel-head' }, h('h3', null, title), iconBtn('x', t('close'), () => closePanel()));

async function renderInfo() {
  const c = S.convs.get(S.activeId); if (!c) return;
  const box = aside(); clear(box).append(head(t('info')), h('div', { class: 'panel-body' }, h('p', { class: 'loading' }, t('loading'))));
  let members = []; let full = c;
  try { const r = await api('GET', `/api/conversations/${c.id}`); members = r.members; full = r.conv; upsertConv(full); members.forEach(cacheUser); } catch (e) { toast(errText(e), 'error'); return; }
  if (S.panel !== 'info' || S.activeId !== c.id) return;
  const body = h('div', { class: 'panel-body' });
  const dm = c.type === 'dm', admin = ['owner', 'admin'].includes(full.my.role);
  const person = dm ? full.peer : null;
  body.append(h('div', { class: 'profile' }, avatar(convAvatarSrc(full), 88, dm ? { dot: S.online.has(person.id) } : { group: true }),
    h('h2', null, convTitle(full)), dm ? h('p', { class: 'muted' }, '@' + person.username) : h('p', { class: 'muted' }, full.description || ''),
    dm && person.status_text ? h('p', { class: 'status' }, person.status_text) : null,
    !dm ? h('p', { class: 'muted' }, h('span', { class: 'chip' }, icon(full.is_public ? 'globe' : 'lock', 13), t(full.is_public ? 'public' : 'private')), ' ', t('n_members', { n: full.member_count })) : null));
  body.append(h('div', { class: 'quick' },
    qbtn(full.my.muted ? 'bellOff' : 'bell', full.my.muted ? t('unmute') : t('mute'), () => patchMe({ muted: !full.my.muted }).then(renderInfo)),
    qbtn('pin', full.my.pinned ? t('unpin_chat') : t('pin_chat'), () => patchMe({ pinned: !full.my.pinned }).then(renderInfo)),
    qbtn('archive', full.my.archived ? t('unarchive') : t('archive'), () => patchMe({ archived: !full.my.archived }).then(renderInfo))));

  if (dm) {
    const blocked = S.blocked.some((b) => b.id === person.id), friend = S.friends.some((f) => f.id === person.id);
    body.append(h('div', { class: 'actions-col' },
      friend ? btn(t('unfriend'), async () => { if (await confirmBox(t('unfriend'), t('unfriend_text', { n: person.display_name }), t('unfriend'))) api('DELETE', `/api/friends/${person.id}`).catch((e) => toast(errText(e), 'error')); }, 'ghost', 'user') : null,
      blocked ? btn(t('unblock'), () => api('DELETE', `/api/blocks/${person.id}`).catch((e) => toast(errText(e), 'error')), 'ghost', 'ban')
        : btn(t('block'), async () => { if (await confirmBox(t('block'), t('block_text', { n: person.display_name }), t('block'))) api('POST', '/api/blocks', { user_id: person.id }).catch((e) => toast(errText(e), 'error')); }, 'ghost danger-text', 'ban'),
      btn(t('report_user'), () => reportDialog('user', person.id), 'ghost danger-text', 'flag')));
  } else {
    body.append(h('div', { class: 'actions-col' },
      admin ? btn(t('edit_space'), () => editGroupDialog(full), 'ghost', 'edit') : null,
      full.add_policy === 'all' || admin ? btn(t('add_members'), () => addMembersDialog(full, members), 'ghost', 'userPlus') : null,
      btn(t('leave_space'), async () => { if (await confirmBox(t('leave_space'), t('leave_text'), t('leave'))) { try { await api('POST', `/api/conversations/${full.id}/leave`); } catch (e) { toast(errText(e), 'error'); } } }, 'ghost danger-text', 'logout'),
      full.my.role === 'owner' ? btn(t('delete_space'), async () => { if (await confirmBox(t('delete_space'), t('delete_space_text'), t('delete'))) api('DELETE', `/api/conversations/${full.id}`).catch((e) => toast(errText(e), 'error')); }, 'ghost danger-text', 'trash') : null));
    body.append(h('h4', { class: 'sec' }, t('members')), h('div', { class: 'members' }, members.map((m) => {
      const mine = full.my.role; const canManage = m.id !== S.me.id && m.role !== 'owner' && (mine === 'owner' || (mine === 'admin' && m.role === 'member'));
      return h('div', { class: 'member' }, avatar(m, 36, { dot: S.online.has(m.id) || m.id === S.me.id }),
        h('span', { class: 'mi-name' }, h('b', null, m.display_name + (m.id === S.me.id ? ' ' + t('you_paren') : '')), h('small', null, '@' + m.username)),
        m.role !== 'member' ? h('span', { class: 'role ' + m.role }, t('role.' + m.role)) : null,
        m.id !== S.me.id ? iconBtn('more', t('more'), (e) => menu(e.currentTarget, [
          S.friends.some((f) => f.id === m.id) ? { label: t('message'), icon: 'chat', onClick: () => hooks.openDm(m.id) } : null,
          mine === 'owner' && m.role !== 'owner' ? { label: m.role === 'admin' ? t('demote') : t('promote'), icon: 'shield', onClick: () => api('PATCH', `/api/conversations/${full.id}/members/${m.id}`, { role: m.role === 'admin' ? 'member' : 'admin' }).catch((x) => toast(errText(x), 'error')) } : null,
          canManage ? { label: t('remove_member'), icon: 'trash', danger: true, onClick: () => api('DELETE', `/api/conversations/${full.id}/members/${m.id}`).catch((x) => toast(errText(x), 'error')) } : null,
          { label: t('report_user'), icon: 'flag', onClick: () => reportDialog('user', m.id) }]), 'small') : null);
    })));
    body.append(h('details', { class: 'perm' }, h('summary', null, t('permissions')),
      h('table', null, h('thead', null, h('tr', null, h('th'), ['owner', 'admin', 'member'].map((r) => h('th', null, t('role.' + r))))),
        h('tbody', null, [['p_post', full.post_policy === 'all' ? [1, 1, 1] : [1, 1, 0]], ['p_add', full.add_policy === 'all' ? [1, 1, 1] : [1, 1, 0]], ['p_pin', [1, 1, 0]], ['p_delete', [1, 1, 0]], ['p_remove', [1, 1, 0]], ['p_roles', [1, 0, 0]], ['p_delspace', [1, 0, 0]]]
          .map(([k, v]) => h('tr', null, h('td', null, t(k)), v.map((x) => h('td', { class: x ? 'yes' : 'no' }, x ? '✓' : '—'))))))));
  }
  const media = h('div', { class: 'media' });
  const tabs = h('div', { class: 'seg' });
  body.append(h('h4', { class: 'sec' }, t('shared')), tabs, media);
  api('GET', `/api/conversations/${full.id}/media`).then((r) => {
    const draw = (k) => {
      clear(media);
      const list = r[k];
      if (!list.length) media.append(h('p', { class: 'muted' }, t(k === 'files' ? 'no_files' : 'no_links')));
      for (const m of list) {
        if (k === 'files') media.append(m.file.image ? h('a', { class: 'thumb', href: `/api/files/${m.file.id}`, target: '_blank', rel: 'noopener' }, h('img', { src: `/api/files/${m.file.id}`, alt: m.file.name, loading: 'lazy' }))
          : h('a', { class: 'row-file', href: `/api/files/${m.file.id}`, download: m.file.name }, icon('file', 18), h('span', null, h('b', null, m.file.name), h('small', null, fmtSize(m.file.size) + ' · ' + fmtDateTime(m.created_at)))));
        else { const { urls } = linkify(m.body); media.append(h('a', { class: 'row-file', href: urls[0] || '#', target: '_blank', rel: 'noopener noreferrer nofollow' }, icon('link', 18), h('span', null, h('b', null, urls[0] || m.body), h('small', null, m.sender.display_name + ' · ' + fmtDateTime(m.created_at))))); }
      }
      media.classList.toggle('thumbs', k === 'files' && list.some((m) => m.file.image));
    };
    for (const k of ['files', 'links']) tabs.append(h('button', { type: 'button', class: k === 'files' ? 'on' : '', onclick: (e) => { tabs.querySelectorAll('button').forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); draw(k); } }, t(k === 'files' ? 'files' : 'links') + ` (${r[k].length})`));
    draw('files');
  }).catch(() => {});
  clear(box).append(head(t('info')), body);
}
const qbtn = (ic, label, fn) => h('button', { class: 'qbtn', type: 'button', onclick: fn }, icon(ic, 20), h('span', null, label));

function editGroupDialog(c) {
  const name = h('input', { class: 'input', value: c.name, maxlength: 60 }), desc = h('textarea', { class: 'input', rows: 3, maxlength: 300 }, c.description);
  const post = h('select', { class: 'input' }, ['all', 'admins'].map((v) => h('option', { value: v, selected: c.post_policy === v }, t('post_' + v))));
  const add = h('select', { class: 'input' }, ['admins', 'all'].map((v) => h('option', { value: v, selected: c.add_policy === v }, t('add_' + v))));
  const pub = h('input', { type: 'checkbox', checked: c.is_public, disabled: c.my.role !== 'owner' });
  const f = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp', hidden: true, onchange: async () => { try { const up = await uploadFile(f.files[0], { purpose: 'avatar' }); await api('PATCH', `/api/conversations/${c.id}`, { avatar_file: up.id }); toast(t('saved'), 'success'); } catch (e) { toast(errText(e), 'error'); } } });
  const fld = (l, i) => h('label', { class: 'field' }, h('span', null, l), i);
  const m = modal(t('edit_space'), [fld(t('space_name'), name), fld(t('space_desc'), desc), fld(t('who_can_post'), post), fld(t('who_can_add'), add),
    h('label', { class: 'check' }, pub, h('span', null, h('b', null, t('public_space')), h('small', null, c.my.role === 'owner' ? t('public_space_hint') : t('owner_only')))),
    btn(t('change_photo'), () => f.click(), 'ghost small', 'image'), f],
  { actions: [btn(t('cancel'), () => m.close(), 'ghost'), btn(t('save'), async () => {
    try { await api('PATCH', `/api/conversations/${c.id}`, { name: name.value, description: desc.value, post_policy: post.value, add_policy: add.value, ...(c.my.role === 'owner' ? { is_public: pub.checked } : {}) }); m.close(); toast(t('saved'), 'success'); } catch (e) { toast(errText(e), 'error'); }
  }, 'primary')] });
}

// ---------------- threads ----------------
export async function openThread(m) {
  const root = m.thread_root ? C.msgs.find((x) => x.id === m.thread_root) || m : m;
  S.panel = 'thread'; document.body.classList.add('show-panel');
  const box = aside(); clear(box);
  const list = h('div', { class: 'thread-list' }, h('p', { class: 'loading' }, t('loading')));
  const conv = S.convs.get(S.activeId);
  const input = h('textarea', { class: 'input-box', rows: 1, dir: 'auto', maxlength: 4000, placeholder: t('reply_in_thread'), onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); post(); } }, oninput: () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; } });
  const post = async () => {
    const text = input.value.trim(); if (!text) return; input.value = ''; input.style.height = 'auto';
    try { await api('POST', `/api/conversations/${S.activeId}/messages`, { body: text, thread_root: root.id }); } catch (e) { input.value = text; toast(errText(e), 'error'); }
  };
  box.append(head(t('thread')), list, conv.send_block ? h('div', { class: 'composer-off' }, t('sb.' + conv.send_block)) : h('div', { class: 'thread-composer' }, input, iconBtn('send', t('send'), post, 'primary dir')));
  thread = { root, list, msgs: [] };
  try {
    const r = await api('GET', `/api/conversations/${S.activeId}/messages?thread=${root.id}`);
    if (!thread || thread.root.id !== root.id) return;
    thread.msgs = r.messages; draw();
  } catch (e) { list.textContent = errText(e); }
  input.focus();
}
function draw() {
  if (!thread) return; const conv = S.convs.get(S.activeId);
  const items = thread.msgs.map((m, i) => msgEl(m, { prev: thread.msgs[i - 1], conv, inThread: true }));
  items.splice(1, 0, h('div', { class: 'day' }, h('span', null, t('n_replies', { n: Math.max(thread.msgs.length - 1, 0) }))));
  clear(thread.list).append(...items); thread.list.scrollTop = thread.list.scrollHeight;
}
hooks.threadNew = (msg) => { if (thread && msg.thread_root === thread.root.id && !thread.msgs.some((x) => x.id === msg.id)) { thread.msgs.push(msg); draw(); } };
hooks.threadUpdate = (msg) => { if (!thread) return; const i = thread.msgs.findIndex((x) => x.id === msg.id); if (i >= 0) { thread.msgs[i] = msg; draw(); } };
