import { h, $, icon, avatar, iconBtn, btn, clear, menu, toast, modal, closeMenu } from './util.js';
import { t, setLang, getLang } from './i18n.js';
import { S, api, errText, hooks, cacheUser, upsertConv, totalUnread, previewText, convTitle } from './state.js';
import { fmtDateTime } from './util.js';
import * as chat from './chat.js';
import * as panel from './panel.js';
import { renderSide, mountSearch } from './side.js';
import { drawAdminSide, show as showAdmin } from './admin.js';
import { settingsDialog } from './dialogs.js';

// ---------------- theme & language ----------------
const store = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };
let theme = store.get('fs_theme') || 'system';
const mq = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() { document.documentElement.dataset.theme = theme === 'system' ? (mq.matches ? 'dark' : 'light') : theme; document.querySelector('meta[name=theme-color]')?.setAttribute('content', document.documentElement.dataset.theme === 'dark' ? '#0c161b' : '#0b7a85'); }
mq.addEventListener?.('change', () => theme === 'system' && applyTheme());
const pushPrefs = () => S.me && api('PATCH', '/api/me', { prefs: { theme, lang: getLang() } }).catch(() => {});
hooks.getTheme = () => theme;
hooks.setTheme = (v) => { theme = v; store.set('fs_theme', v); applyTheme(); pushPrefs(); refreshThemeBtn(); };
hooks.getLang = getLang;
hooks.setLang = (v) => { if (v === getLang()) return; setLang(v); store.set('fs_lang', v); pushPrefs(); S.me ? rerender() : renderAuth(authMode); };
setLang(store.get('fs_lang') || 'ar'); applyTheme();

// ---------------- boot ----------------
let authMode = 'login', authToken = null;
async function boot() {
  const reset = new URLSearchParams(location.search).get('reset');
  if (reset) { authMode = 'reset'; authToken = reset; history.replaceState(null, '', '/'); renderAuth(); return; }
  try { initData(await api('GET', '/api/bootstrap')); startApp(); } catch (e) { if (e.code !== 'account_suspended') renderAuth(); }
}
function initData(d) {
  S.me = d.me; S.convs = new Map(); S.users = new Map(); d.conversations.forEach(upsertConv);
  applyFriends(d); S.online = new Set(d.online); S.stickers = d.stickers; S.limits = d.limits; S.meeting = d.meeting;
  d.friends.forEach(cacheUser);
  syncPrefs(d.me.prefs);
}
function applyFriends(d) { S.friends = d.friends; S.incoming = d.incoming; S.outgoing = d.outgoing; S.blocked = d.blocked; [...d.friends, ...d.incoming.map((x) => x.user), ...d.outgoing.map((x) => x.user)].forEach(cacheUser); }
function syncPrefs(p) {
  let changed = false;
  if (p?.theme && p.theme !== theme) { theme = p.theme; store.set('fs_theme', theme); applyTheme(); refreshThemeBtn(); }
  if (p?.lang && p.lang !== getLang()) { setLang(p.lang); store.set('fs_lang', p.lang); changed = true; }
  return changed;
}

// ---------------- auth screen ----------------
function renderAuth() {
  document.title = 'FriendSpace';
  const root = $('#root'); clear(root);
  const err = h('p', { class: 'form-err', role: 'alert' });
  const field = (label, props) => h('label', { class: 'field' }, h('span', null, label), h('input', { class: 'input', ...props }));
  let form;
  const submitBtn = (label) => h('button', { class: 'btn primary block', type: 'submit' }, label);
  const run = (fn) => async (e) => { e.preventDefault(); err.textContent = ''; const b = form.querySelector('button[type=submit]'); b.disabled = true; try { await fn(new FormData(form)); } catch (x) { err.textContent = errText(x); } finally { b.disabled = false; } };
  const enter = async () => { initData(await api('GET', '/api/bootstrap')); startApp(); };
  if (authMode === 'login') form = h('form', { onsubmit: run(async (f) => { await api('POST', '/api/auth/login', { identifier: f.get('id'), password: f.get('pw') }); await enter(); }) },
    h('h1', null, t('login')), field(t('email_or_username'), { name: 'id', autocomplete: 'username', required: true, autofocus: true }), field(t('password'), { name: 'pw', type: 'password', autocomplete: 'current-password', required: true }),
    err, submitBtn(t('login')), h('button', { class: 'link', type: 'button', onclick: () => { authMode = 'forgot'; renderAuth(); } }, t('forgot_password')),
    h('p', { class: 'switch' }, t('no_account'), ' ', h('button', { class: 'link', type: 'button', onclick: () => { authMode = 'register'; renderAuth(); } }, t('create_account'))));
  else if (authMode === 'register') form = h('form', { onsubmit: run(async (f) => { await api('POST', '/api/auth/register', { email: f.get('email'), username: f.get('username'), display_name: f.get('name'), password: f.get('pw') }); await enter(); }) },
    h('h1', null, t('create_account')), field(t('display_name'), { name: 'name', maxlength: 40, required: true, autocomplete: 'name' }),
    field(t('username'), { name: 'username', maxlength: 24, required: true, pattern: '[A-Za-z0-9_.]{3,24}', autocapitalize: 'none', dir: 'ltr', title: t('username_rules') }),
    field(t('email'), { name: 'email', type: 'email', required: true, autocomplete: 'email', dir: 'ltr' }), field(t('password'), { name: 'pw', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' }),
    h('small', { class: 'hint' }, t('password_rules')), err, submitBtn(t('create_account')),
    h('p', { class: 'switch' }, t('have_account'), ' ', h('button', { class: 'link', type: 'button', onclick: () => { authMode = 'login'; renderAuth(); } }, t('login'))));
  else if (authMode === 'forgot') form = h('form', { onsubmit: run(async (f) => { await api('POST', '/api/auth/forgot', { email: f.get('email') }); err.className = 'form-ok'; err.textContent = t('reset_sent'); }) },
    h('h1', null, t('forgot_password')), h('p', { class: 'muted' }, t('forgot_hint')), field(t('email'), { name: 'email', type: 'email', required: true, dir: 'ltr' }), err, submitBtn(t('send_reset')),
    h('button', { class: 'link', type: 'button', onclick: () => { authMode = 'login'; renderAuth(); } }, t('back_to_login')));
  else form = h('form', { onsubmit: run(async (f) => { await api('POST', '/api/auth/reset', { token: authToken, password: f.get('pw') }); authMode = 'login'; renderAuth(); toast(t('password_changed'), 'success'); }) },
    h('h1', null, t('reset_password')), field(t('new_password'), { name: 'pw', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' }), h('small', { class: 'hint' }, t('password_rules')), err, submitBtn(t('reset_password')));
  root.append(h('main', { class: 'auth' },
    h('section', { class: 'auth-brand' }, h('img', { src: '/img/logo.svg', alt: '', width: 56, height: 56 }), h('h2', null, 'FriendSpace'), h('p', null, t('tagline')),
      h('ul', null, ['f1', 'f2', 'f3'].map((k) => h('li', null, icon('check', 18), t(k))))),
    h('section', { class: 'auth-card' }, h('div', { class: 'auth-tools' }, themeBtn(), iconBtn('globe', t('language'), () => hooks.setLang(getLang() === 'ar' ? 'en' : 'ar'))), form)));
}
let themeBtnEl;
function themeBtn() { themeBtnEl = iconBtn(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', t('theme'), () => hooks.setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark')); return themeBtnEl; }
function refreshThemeBtn() { document.querySelectorAll('.theme-btn').forEach((b) => { b.replaceChildren(icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', 20)); }); if (themeBtnEl?.isConnected) themeBtnEl.replaceChildren(icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', 20)); }

// ---------------- suspension notice & appeal ----------------
let suspTimer;
let violationShown = false; // the "message blocked" explanation must be read before the suspension screen replaces the app
hooks.onSuspended = () => { if (!violationShown && !document.querySelector('.susp')) showSuspension(); };
hooks.onViolation = (d) => {
  const c = t('viol.' + d.category); if (d.suspended_until) violationShown = true;
  setTimeout(() => modal(t('viol.blocked_title'), h('p', null, t(d.suspended_until ? 'viol.blocked_text' : 'viol.blocked_admin', { c })), { actions: [btn(t('continue'), () => { document.querySelector('.modal-back')?.remove(); if (d.suspended_until) showSuspension(); }, 'primary')], onClose: () => { if (d.suspended_until) showSuspension(); } }), 0);
};
async function showSuspension(pre) {
  violationShown = false;
  let info = pre;
  if (!info) { try { info = (await api('GET', '/api/suspension')).suspension; } catch { return; } }
  if (!info) { location.reload(); return; }
  try { S.ws?.close(); } catch {} S.ws = null; S.me = null; S.activeId = null; clearInterval(suspTimer);
  document.querySelectorAll('.modal-back').forEach((x) => x.remove()); document.body.classList.remove('show-chat', 'show-panel');
  const root = $('#root'); clear(root);
  const days = Math.max(1, Math.ceil((info.suspended_until - Date.now()) / 864e5));
  const v = info.violation; const a = info.appeal;
  const row = (k, val) => h('div', { class: 'srow2' }, h('span', null, k), h('b', null, val));
  const ta = h('textarea', { class: 'input', rows: 4, maxlength: 1000, placeholder: t('susp.appeal_ph'), 'aria-label': t('susp.appeal_title') });
  const err = h('p', { class: 'form-err', role: 'alert' });
  const send = btn(t('susp.appeal_send'), async () => {
    err.textContent = '';
    try { const r = await api('POST', '/api/appeals', { text: ta.value }); toast(t('susp.appeal_sent'), 'success'); showSuspension(r.suspension); } catch (e) { err.textContent = errText(e); }
  }, 'primary');
  root.append(h('main', { class: 'susp' }, h('div', { class: 'susp-card' },
    h('img', { src: '/img/logo.svg', alt: '', width: 48, height: 48 }), h('h1', null, t('susp.title')), h('p', { class: 'muted' }, t('susp.intro', { n: info.days })),
    h('div', { class: 'susp-facts' },
      v ? row(t('susp.reason'), t('viol.' + v.category)) : null, v ? row(t('susp.where'), t('ctx.' + v.context)) : null,
      row(t('susp.when'), fmtDateTime(info.suspended_at)), row(t('susp.until'), fmtDateTime(info.suspended_until) + ' — ' + t('susp.remaining', { n: days }))),
    v ? h('div', { class: 'susp-quote' }, h('small', null, t('susp.text')), h('blockquote', { dir: 'auto' }, v.text)) : null,
    h('p', { class: 'muted' }, t('susp.no_access')),
    h('section', { class: 'appeal' }, h('h2', null, t('susp.appeal_title')),
      info.can_appeal ? [h('p', { class: 'muted' }, t('susp.appeal_hint')), ta, err, send]
        : a ? [h('div', { class: 'appeal-status ' + a.status }, t(a.status === 'open' ? 'susp.appeal_open' : a.status === 'accepted' ? 'susp.appeal_accepted' : 'susp.appeal_rejected')),
          h('blockquote', { dir: 'auto' }, a.text), a.response ? h('p', null, h('b', null, t('susp.response') + ': '), a.response) : null] : null),
    h('div', { class: 'susp-actions' }, btn(t('susp.check'), () => checkSusp(), 'ghost', 'check'), btn(t('logout'), async () => { clearInterval(suspTimer); try { await api('POST', '/api/auth/logout'); } catch {} authMode = 'login'; renderAuth(); }, 'ghost', 'logout')))));
  document.title = 'FriendSpace';
  window.__suspAppeal = info.appeal; suspTimer = setInterval(checkSusp, 30000);
}
async function checkSusp() {
  try { const r = await api('GET', '/api/suspension'); if (!r.suspension) { clearInterval(suspTimer); toast(t('susp.lifted'), 'success'); setTimeout(() => location.reload(), 800); } else if (JSON.stringify(r.suspension.appeal) !== JSON.stringify(window.__suspAppeal)) { window.__suspAppeal = r.suspension.appeal; showSuspension(r.suspension); } } catch {}
}

// ---------------- app shell ----------------
function buildShell() {
  const root = $('#root'); clear(root);
  const staff = S.me.role === 'admin' || S.me.role === 'moderator';
  const tab = (k, ic, label) => h('button', { class: 'rbtn', type: 'button', dataset: { tab: k }, 'aria-label': label, title: label, onclick: () => switchTab(k) }, icon(ic, 22), h('span', { class: 'rl' }, label), h('i', { class: 'badge', hidden: true }));
  const host = h('div', { class: 'search-host' });
  const tbtn = iconBtn(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', t('theme'), () => hooks.setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'), 'theme-btn');
  const meBtn = h('button', { class: 'me-btn', type: 'button', 'aria-label': t('account'), onclick: (e) => menu(e.currentTarget, [
    { label: t('settings'), icon: 'settings', onClick: settingsDialog },
    { label: t('logout'), icon: 'logout', onClick: logout }]) }, avatar(S.me, 36));
  root.append(h('div', { id: 'app' },
    h('header', { class: 'topbar' }, h('div', { class: 'brand' }, h('img', { src: '/img/logo.svg', alt: '', width: 32, height: 32 }), h('b', null, 'FriendSpace')), host,
      h('div', { class: 'top-actions' }, tbtn, iconBtn('globe', t('language'), () => hooks.setLang(getLang() === 'ar' ? 'en' : 'ar')), meBtn)),
    h('nav', { class: 'rail', 'aria-label': t('main_nav') }, tab('chats', 'chat', t('chats')), tab('contacts', 'users', t('contacts')), tab('spaces', 'grid', t('spaces')), staff ? tab('admin', 'shield', t('admin')) : null, h('span', { class: 'grow' }), h('button', { class: 'rbtn desk-only', type: 'button', 'aria-label': t('settings'), title: t('settings'), onclick: settingsDialog }, icon('sliders', 22), h('span', { class: 'rl' }, t('settings')))),
    h('aside', { id: 'side' }, h('header', { class: 'side-head' }, h('h2', { id: 'sidetitle' }), h('span', { id: 'sideact' })), h('div', { id: 'sidebody' })),
    h('main', { id: 'main' }), h('aside', { id: 'info', 'aria-label': t('info') }),
    h('div', { id: 'netbar', hidden: true }, icon('wifiOff', 16), t('reconnecting'))));
  mountSearch(host);
}
function switchTab(k) {
  const was = S.tab; S.tab = k; document.body.classList.remove('show-chat');
  if (k === 'admin') { renderSide(); return; }
  if (was === 'admin') { if (S.activeId) chat.openConversation(S.activeId); else chat.emptyMain(); }
  renderSide();
}
function rerender() { const a = S.activeId; buildShell(); renderSide(); if (S.tab === 'admin') showAdmin(); else if (a) chat.openConversation(a); else chat.emptyMain(); updateTitle(); }

function startApp() {
  S.tab = 'chats'; S.activeId = null; buildShell(); renderSide(); chat.emptyMain(); updateTitle(); connectWs(); loadAnnouncements();
  if ('Notification' in window && Notification.permission === 'default' && !store.get('fs_notif_asked')) {
    store.set('fs_notif_asked', '1');
    setTimeout(() => toast(t('notif_prompt'), 'info', () => { try { Notification.requestPermission(); } catch {} }), 2500);
  }
}
async function logout() { try { await api('POST', '/api/auth/logout'); } catch {} hooks.sessionLost(); }
hooks.sessionLost = (msg) => {
  if (!S.me) return; S.me = null; try { S.ws?.close(); } catch {} S.ws = null; S.activeId = null; closeMenu();
  document.querySelectorAll('.modal-back').forEach((x) => x.remove());
  document.body.classList.remove('show-chat', 'show-panel'); authMode = 'login'; renderAuth();
  if (msg) toast(msg, 'info');
};

function updateTitle() { const n = totalUnread(); document.title = (n ? `(${n}) ` : '') + 'FriendSpace'; }
hooks.refreshSide = () => { renderSide(); updateTitle(); };
hooks.open = (id) => { if (S.tab === 'admin') S.tab = 'chats'; chat.openConversation(id); };
hooks.openAround = (cid, mid) => { if (S.tab === 'admin') S.tab = 'chats'; chat.openConversation(cid, { around: mid }); };
hooks.openDm = async (uid) => {
  let c = [...S.convs.values()].find((x) => x.type === 'dm' && x.peer.id === uid);
  if (!c) { try { c = (await api('POST', '/api/conversations/dm', { user_id: uid })).conv; upsertConv(c); } catch (e) { toast(errText(e), 'error'); return; } }
  S.tab = 'chats'; hooks.open(c.id);
};
hooks.afterCreate = (c) => { upsertConv(c); S.tab = 'chats'; hooks.open(c.id); };
hooks.closeChat = () => { S.activeId = null; document.body.classList.remove('show-chat', 'show-panel'); chat.emptyMain(); renderSide(); };
hooks.togglePanel = panel.togglePanel; hooks.closePanel = panel.closePanel; hooks.refreshPanel = panel.refreshPanel; hooks.openThread = panel.openThread;
hooks.reply = chat.startReply; hooks.edit = chat.startEdit; hooks.jumpTo = chat.jumpTo; hooks.drawAdminSide = drawAdminSide;

// ---------------- realtime ----------------
let retry = 0, hbTimer, wasDown = false;
function dismissedIds() { try { return JSON.parse(localStorage.getItem('fs.dismissed') || '[]'); } catch { return []; } }
function showAnnouncement(a) {
  if (!a || dismissedIds().includes(a.id) || document.querySelector(`.announce[data-id="${a.id}"]`)) return;
  const bar = h('div', { class: 'announce', role: 'status', 'data-id': a.id }, icon('bell', 18), h('span', null, a.body), iconBtn('x', t('close'), () => { bar.remove(); try { localStorage.setItem('fs.dismissed', JSON.stringify([...dismissedIds(), a.id].slice(-50))); } catch {} }));
  document.body.prepend(bar);
}
async function loadAnnouncements() { try { (await api('GET', '/api/announcements')).announcements.reverse().forEach(showAnnouncement); } catch {} }
function connectWs() {
  if (!S.me) return;
  const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
  S.ws = ws;
  ws.onopen = () => {
    retry = 0; S.wsUp = true; $('#netbar') && ($('#netbar').hidden = true);
    clearInterval(hbTimer); hbTimer = setInterval(() => ws.readyState === 1 && ws.send('{"t":"ping"}'), 30000);
    if (wasDown) { wasDown = false; resync(); }
  };
  ws.onmessage = (e) => { try { onEvent(JSON.parse(e.data)); } catch (x) { console.error(x); } };
  ws.onclose = (e) => {
    S.wsUp = false; clearInterval(hbTimer);
    if (!S.me || S.ws !== ws) return;
    if (e.code === 4001) { setTimeout(() => { if (violationShown || !S.me) return; api('GET', '/api/me').then((r) => { if (r.suspension) showSuspension(r.suspension); }).catch(() => {}); }, 1200); return; } // delayed: the "message blocked" explanation (HTTP reply) may still be on its way // revoked: login screen (401) or suspension notice
    wasDown = true; $('#netbar') && ($('#netbar').hidden = false);
    setTimeout(connectWs, Math.min(15000, 800 * 2 ** retry++));
  };
}
addEventListener('online', () => { if (S.me && !S.wsUp) { retry = 0; connectWs(); } });
async function resync() {
  try {
    const keep = S.activeId; initData(await api('GET', '/api/bootstrap')); renderSide(); updateTitle();
    if (keep && S.convs.has(keep)) { S.activeId = keep; await chat.reloadActive(); chat.updateHeader(); }
  } catch {}
}
async function refreshFriends() { try { applyFriends(await api('GET', '/api/friends')); renderSide(); hooks.refreshBlocked?.(); if (S.panel === 'info') panel.refreshPanel(); } catch {} }

function notifyMessage(msg) {
  if (msg.sender.id === S.me.id || msg.kind === 'system' || msg.thread_root && S.panel === 'thread') return;
  const c = S.convs.get(msg.conv_id); if (c?.my.muted) return;
  if (msg.conv_id === S.activeId && !document.hidden) return;
  const title = c?.type === 'group' ? `${c.name} · ${msg.sender.display_name}` : msg.sender.display_name;
  const body = msg.kind === 'sticker' ? msg.body : msg.kind === 'meeting' ? t('meeting_link') : msg.file ? '📎 ' + (msg.body || msg.file.name) : msg.body;
  const go = () => { window.focus(); hooks.open(msg.conv_id); };
  toast(h('span', null, h('b', null, title), h('br'), String(body).slice(0, 90)), 'msg', go);
  if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
    try { const n = new Notification(title, { body: String(body).slice(0, 140), icon: '/img/logo.svg', tag: 'conv-' + msg.conv_id }); n.onclick = () => { go(); n.close(); }; } catch {}
  }
}

async function onEvent(ev) {
  switch (ev.t) {
    case 'message.new': {
      cacheUser(ev.msg.sender);
      if (!S.convs.has(ev.msg.conv_id)) { try { const r = await api('GET', `/api/conversations/${ev.msg.conv_id}`); upsertConv(r.conv); hooks.refreshSide(); } catch {} }
      chat.handleNew(ev.msg, ev.client_id); notifyMessage(ev.msg); break;
    }
    case 'message.update': chat.handleUpdate(ev.msg); break;
    case 'conv': {
      const was = S.convs.get(ev.conv.id); upsertConv(ev.conv);
      if (S.activeId === ev.conv.id) { chat.updateHeader(); chat.updateTicks(); if (S.panel === 'info') panel.refreshPanel(); }
      else if (was && ev.conv.unread === 0) { /* synced */ }
      hooks.refreshSide(); break;
    }
    case 'conv.remove': {
      S.convs.delete(ev.conv);
      if (S.activeId === ev.conv) { S.activeId = null; panel.closePanel(); chat.emptyMain(); toast(t('removed_from_space'), 'info'); }
      hooks.refreshSide(); break;
    }
    case 'friends': refreshFriends(); break;
    case 'presence': {
      ev.online ? S.online.add(ev.user_id) : S.online.delete(ev.user_id);
      const u = S.users.get(ev.user_id); if (u) u.last_seen = ev.last_seen;
      renderSide(); chat.updateHeader(); break;
    }
    case 'typing': {
      let m = S.typing.get(ev.conv); if (!m) S.typing.set(ev.conv, (m = new Map()));
      clearTimeout(m.get(ev.user_id)?.timer);
      m.set(ev.user_id, { name: ev.name, timer: setTimeout(() => { m.delete(ev.user_id); chat.updateHeader(); }, 4000) });
      if (ev.conv === S.activeId) chat.updateHeader(); break;
    }
    case 'delivered': case 'read': {
      const c = S.convs.get(ev.conv);
      if (c?.type === 'dm' && ev.user_id === c.peer.id) {
        if (ev.t === 'read') { c.peer_read_id = Math.max(c.peer_read_id || 0, ev.up_to); c.peer_delivered_id = Math.max(c.peer_delivered_id || 0, ev.up_to); }
        else c.peer_delivered_id = Math.max(c.peer_delivered_id || 0, ev.up_to);
        if (ev.conv === S.activeId) chat.updateTicks();
      }
      break;
    }
    case 'self.read': {
      const c = S.convs.get(ev.conv); if (!c) break;
      c.my.last_read_id = Math.max(c.my.last_read_id, ev.up_to);
      if (!c.last_message || c.last_message.id <= ev.up_to) c.unread = 0;
      else { try { upsertConv((await api('GET', `/api/conversations/${ev.conv}`)).conv); } catch {} }
      hooks.refreshSide(); break;
    }
    case 'user.update': {
      cacheUser(ev.user);
      for (const c of S.convs.values()) if (c.peer?.id === ev.user.id) c.peer = { ...c.peer, ...ev.user };
      for (const list of [S.friends]) { const i = list.findIndex((f) => f.id === ev.user.id); if (i >= 0) list[i] = { ...list[i], ...ev.user }; }
      renderSide(); if (S.activeId) { chat.updateHeader(); } break;
    }
    case 'me.update': {
      S.me = ev.me; const lg = syncPrefs(ev.me.prefs);
      if (lg) rerender(); else { const mb = $('.me-btn'); mb?.replaceChildren(avatar(S.me, 36)); }
      break;
    }
    case 'announce': showAnnouncement(ev.announcement); break;
    case 'notify': if (ev.kind === 'friend_request') {
      toast(t('friend_request_from', { n: ev.from.display_name }), 'msg', () => { S.tab = 'contacts'; renderSide(); });
      if (document.hidden && 'Notification' in window && Notification.permission === 'granted') try { new Notification('FriendSpace', { body: t('friend_request_from', { n: ev.from.display_name }), icon: '/img/logo.svg' }); } catch {}
    } break;
  }
}

document.addEventListener('visibilitychange', () => { if (!document.hidden) chat.scheduleRead(); });
addEventListener('focus', () => chat.scheduleRead());
addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && S.me) { e.preventDefault(); hooks.focusSearch?.(); } });

boot();
