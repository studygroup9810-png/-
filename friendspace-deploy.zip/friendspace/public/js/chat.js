import { h, $, icon, avatar, iconBtn, btn, clear, popup, menu, closeMenu, toast, fmtDay, sameDay } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks, uploadFile, convTitle, convAvatarSrc, upsertConv, userById } from './state.js';
import { msgEl, tickState, tickEl } from './msg.js';
import { EMOJI } from './emoji.js';
import { advancedSearchDialog } from './dialogs.js';

export const C = { msgs: [], hasBefore: false, detached: false, pins: [], pinIdx: 0, reply: null, edit: null, file: null, boundary: 0, loading: false, pend: new Map(), unseen: 0 };
const R = {}; // dom refs
let readTimer;

const conv = () => S.convs.get(S.activeId);
const nearBottom = () => R.list && R.list.scrollHeight - R.list.scrollTop - R.list.clientHeight < 140;
const toBottom = () => { if (R.list) R.list.scrollTop = R.list.scrollHeight; };
const uid = () => Math.random().toString(36).slice(2, 10);

export function emptyMain() {
  S.activeId = null; document.body.classList.remove('show-chat');
  clear($('#main')).append(h('div', { class: 'empty' }, h('img', { src: '/img/logo.svg', alt: '', width: 72, height: 72 }), h('h2', null, t('welcome', { n: S.me.display_name.split(' ')[0] })), h('p', null, t('welcome_hint'))));
}

export async function openConversation(id, { around = null } = {}) {
  const c = S.convs.get(id); if (!c) return;
  const switching = S.activeId !== id;
  S.activeId = id; hooks.closePanel?.(true);
  if (switching) { C.reply = null; C.edit = null; C.file = null; C.pend.clear(); C.unseen = 0; C.boundary = c.unread ? c.my.last_read_id : 0; S.typing.delete(id); }
  C.detached = false;
  build();
  document.body.classList.add('show-chat');
  await loadMessages({ around });
  loadPins();
  scheduleRead();
  hooks.refreshSide();
  if (!around) R.input?.focus({ preventScroll: true });
}

function build() {
  const c = conv(); const dm = c.type === 'dm';
  R.sub = h('span', { class: 'sub' });
  R.head = h('header', { class: 'chat-head' },
    iconBtn('back', t('back'), () => hooks.closeChat(), 'back-btn dir'),
    h('button', { class: 'who', type: 'button', onclick: () => hooks.togglePanel('info'), 'aria-label': t('info') },
      avatar(convAvatarSrc(c), 40, dm ? { dot: S.online.has(c.peer.id) } : { group: true }), h('span', { class: 'names' }, h('b', null, convTitle(c)), R.sub)),
    h('div', { class: 'head-actions' },
      S.meeting ? iconBtn('video', t('start_meeting'), startMeeting) : null,
      iconBtn('search', t('search_in_chat'), () => advancedSearchDialog({ conv: c.id })),
      iconBtn('info', t('info'), () => hooks.togglePanel('info')),
      iconBtn('more', t('more'), (e) => chatMenu(e.currentTarget))));
  R.pinbar = h('button', { class: 'pinbar', type: 'button', hidden: true, onclick: cyclePin });
  R.list = h('div', { class: 'msglist', tabindex: 0, onscroll: onScroll, 'aria-live': 'polite', 'aria-label': t('messages') });
  R.jump = h('button', { class: 'jump', type: 'button', hidden: true, onclick: jumpLatest }, icon('down', 18), h('span', null));
  R.typing = h('div', { class: 'typing-line' });
  R.composer = h('div', { class: 'composer' });
  const wrap = h('section', { class: 'chat', ondragover: (e) => { if (e.dataTransfer?.types?.includes('Files')) { e.preventDefault(); wrap.classList.add('drop'); } }, ondragleave: (e) => { if (e.target === wrap) wrap.classList.remove('drop'); }, ondrop: (e) => { e.preventDefault(); wrap.classList.remove('drop'); if (e.dataTransfer.files[0]) attach(e.dataTransfer.files[0]); } },
    R.head, R.pinbar, h('div', { class: 'listwrap' }, R.list, R.jump), R.typing, R.composer);
  clear($('#main')).append(wrap);
  buildComposer(); updateHeader();
}

export function updateHeader() {
  const c = conv(); if (!c || !R.sub) return;
  const tp = S.typing.get(c.id);
  if (tp && tp.size) { R.sub.textContent = ''; R.sub.className = 'sub typing'; R.sub.append(h('i', { class: 'dots' }, h('s'), h('s'), h('s')), c.type === 'dm' ? t('typing') : [...tp.values()].map((x) => x.name).join('، ') + ' ' + t('typing_many')); }
  else if (c.type === 'dm') { const on = S.online.has(c.peer.id); R.sub.className = 'sub' + (on ? ' online' : ''); R.sub.textContent = on ? t('online') : (c.peer.status_text || t('offline')); }
  else { R.sub.className = 'sub'; R.sub.textContent = t('n_members', { n: c.member_count }); }
  const dot = R.head.querySelector('.dot'); if (dot && c.type === 'dm') dot.classList.toggle('on', S.online.has(c.peer.id));
  R.typing.textContent = '';
  if (R.composer) buildComposer(true);
}

function chatMenu(anchor) {
  const c = conv();
  menu(anchor, [
    { label: c.my.pinned ? t('unpin_chat') : t('pin_chat'), icon: 'pin', onClick: () => patchMe({ pinned: !c.my.pinned }) },
    { label: c.my.muted ? t('unmute') : t('mute'), icon: c.my.muted ? 'bell' : 'bellOff', onClick: () => patchMe({ muted: !c.my.muted }) },
    { label: c.my.archived ? t('unarchive') : t('archive'), icon: 'archive', onClick: () => patchMe({ archived: !c.my.archived }) },
    { label: t('info'), icon: 'info', onClick: () => hooks.togglePanel('info') },
  ]);
}
export async function patchMe(p) { try { const r = await api('PATCH', `/api/conversations/${S.activeId}/me`, p); upsertConv(r.conv); hooks.refreshSide(); } catch (e) { toast(errText(e), 'error'); } }

async function startMeeting() {
  try { await api('POST', `/api/conversations/${S.activeId}/meeting`); toast(t('meeting_created'), 'success'); } catch (e) { toast(errText(e), 'error'); }
}

// ---------------- messages ----------------
async function loadMessages({ around } = {}) {
  const id = S.activeId;
  R.list.replaceChildren(h('div', { class: 'loading' }, t('loading')));
  try {
    const r = await api('GET', `/api/conversations/${id}/messages?` + (around ? `around=${around}` : 'limit=40'));
    if (id !== S.activeId) return;
    C.msgs = r.messages; C.hasBefore = r.has_more_before; C.detached = !!around && r.has_more_after;
    renderMessages();
    if (around) focusMsg(around); else toBottom();
    updateJump();
  } catch (e) { R.list.replaceChildren(h('div', { class: 'loading' }, errText(e), ' ', btn(t('retry'), () => loadMessages({ around }), 'ghost small'))); }
}

function renderMessages() {
  const c = conv(); const frag = document.createDocumentFragment();
  if (C.hasBefore) frag.append(h('div', { class: 'older' }, t('loading')));
  else if (c) frag.append(h('div', { class: 'start-note' }, icon('lock', 14), t(c.type === 'dm' ? 'start_dm' : 'start_group')));
  let prev = null, divided = false;
  for (const m of C.msgs) {
    if (!prev || !sameDay(prev.created_at, m.created_at)) frag.append(h('div', { class: 'day' }, h('span', null, fmtDay(m.created_at))));
    if (!divided && C.boundary && m.id > C.boundary && m.sender.id !== S.me.id && m.kind !== 'system') { frag.append(h('div', { class: 'newdiv', id: 'newdiv' }, h('span', null, t('new_messages')))); divided = true; }
    frag.append(msgEl(m, { prev, conv: c })); prev = m;
  }
  for (const el of C.pend.values()) frag.append(el);
  R.list.replaceChildren(frag);
  if (!C.msgs.length && !C.pend.size) R.list.append(h('div', { class: 'loading' }, t('say_hi')));
}

function focusMsg(id) {
  const el = R.list.querySelector(`.msg[data-id="${id}"]`);
  if (!el) return;
  el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1800);
}
export function jumpTo(id) {
  if (R.list?.querySelector(`.msg[data-id="${id}"]`)) focusMsg(id); else openConversation(S.activeId, { around: id });
}
async function jumpLatest() { C.unseen = 0; C.boundary = 0; await openConversation(S.activeId); }

async function loadOlder() {
  if (C.loading || !C.hasBefore || !C.msgs.length) return;
  C.loading = true; const id = S.activeId;
  try {
    const r = await api('GET', `/api/conversations/${id}/messages?limit=40&before=${C.msgs[0].id}`);
    if (id !== S.activeId) return;
    const oh = R.list.scrollHeight, ot = R.list.scrollTop;
    C.msgs = [...r.messages, ...C.msgs]; C.hasBefore = r.has_more_before; renderMessages();
    R.list.scrollTop = ot + (R.list.scrollHeight - oh);
  } catch (e) { toast(errText(e), 'error'); } finally { C.loading = false; }
}

function onScroll() {
  if (R.list.scrollTop < 160) loadOlder();
  if (nearBottom()) { if (!C.detached) { C.unseen = 0; updateJump(); scheduleRead(); } }
  else updateJump();
}
function updateJump() {
  const show = C.detached || !nearBottom();
  R.jump.hidden = !show;
  R.jump.querySelector('span').textContent = C.unseen ? t('new_n', { n: C.unseen }) : t('latest');
  R.jump.classList.toggle('has-new', !!C.unseen);
}

export function handleNew(msg, clientId) {
  const c = S.convs.get(msg.conv_id);
  if (msg.conv_id !== S.activeId) return;
  if (msg.thread_root) { // reply in a thread: bump counter on its root, show in thread panel if open
    const root = C.msgs.find((x) => x.id === msg.thread_root);
    if (root) { root.thread_count = (root.thread_count || 0) + 1; replaceEl(root); }
    hooks.threadNew?.(msg); return;
  }
  if (clientId && C.pend.has(clientId)) { C.pend.get(clientId).remove(); C.pend.delete(clientId); }
  if (C.msgs.some((x) => x.id === msg.id)) return;
  if (C.detached) { C.unseen++; updateJump(); return; }
  const stick = nearBottom() || msg.sender.id === S.me.id;
  const prev = C.msgs.at(-1); C.msgs.push(msg);
  R.list.querySelector('.loading')?.remove();
  if (!prev || !sameDay(prev.created_at, msg.created_at)) R.list.append(h('div', { class: 'day' }, h('span', null, fmtDay(msg.created_at))));
  R.list.append(msgEl(msg, { prev, conv: c }));
  for (const el of C.pend.values()) R.list.append(el);
  if (stick) { toBottom(); if (!document.hidden) scheduleRead(); }
  else { C.unseen++; updateJump(); }
  if (msg.sender.id !== S.me.id) { const tp = S.typing.get(msg.conv_id); tp?.delete(msg.sender.id); updateHeader(); }
}
function replaceEl(m) {
  const old = R.list?.querySelector(`.msg[data-id="${m.id}"]`); if (!old) return;
  const i = C.msgs.findIndex((x) => x.id === m.id);
  old.replaceWith(msgEl(m, { prev: C.msgs[i - 1], conv: conv() }));
}
export function handleUpdate(msg) {
  hooks.threadUpdate?.(msg);
  if (msg.conv_id !== S.activeId) return;
  const i = C.msgs.findIndex((x) => x.id === msg.id);
  if (i >= 0) { msg.thread_count = msg.thread_count ?? C.msgs[i].thread_count; C.msgs[i] = msg; replaceEl(msg); }
  loadPins();
}
export function updateTicks() {
  const c = conv(); if (!c || c.type !== 'dm' || !R.list) return;
  for (const el of R.list.querySelectorAll('.msg.own:not(.pending)')) {
    const id = +el.dataset.id; const st = tickState(c, { id }); const old = el.querySelector('.ticks');
    if (old && st && !old.classList.contains(st)) old.replaceWith(tickEl(st));
  }
}

// ---------------- read receipts ----------------
export function scheduleRead() {
  clearTimeout(readTimer);
  readTimer = setTimeout(async () => {
    const c = conv(); if (!c || document.hidden || C.detached || !nearBottom()) return;
    const last = C.msgs.at(-1); if (!last || (c.unread === 0 && last.id <= c.my.last_read_id)) return;
    try { await api('POST', `/api/conversations/${c.id}/read`, { up_to: last.id }); c.unread = 0; c.my.last_read_id = Math.max(c.my.last_read_id, last.id); hooks.refreshSide(); } catch {}
  }, 250);
}

// ---------------- pins ----------------
async function loadPins() {
  try { const r = await api('GET', `/api/conversations/${S.activeId}/pins`); C.pins = r.messages; C.pinIdx = 0; renderPin(); } catch {}
}
function renderPin() {
  if (!R.pinbar) return;
  R.pinbar.hidden = !C.pins.length; if (!C.pins.length) return;
  const m = C.pins[C.pinIdx % C.pins.length];
  clear(R.pinbar).append(icon('pin', 16), h('span', { class: 'pin-body' }, h('b', null, t('pinned') + (C.pins.length > 1 ? ` ${C.pinIdx % C.pins.length + 1}/${C.pins.length}` : '')), h('span', null, m.file ? '📎 ' + m.file.name : m.kind === 'sticker' ? m.body : m.body)));
}
function cyclePin() { if (!C.pins.length) return; jumpTo(C.pins[C.pinIdx % C.pins.length].id); C.pinIdx++; renderPin(); }

// ---------------- composer ----------------
export function buildComposer(soft) {
  const c = conv(); if (!c) return;
  const blocked = c.send_block;
  if (soft && R.composer.dataset.blocked === String(blocked || '') && R.composer.firstChild) return;
  R.composer.dataset.blocked = blocked || '';
  if (blocked) { clear(R.composer).append(h('div', { class: 'composer-off' }, icon('lock', 16), t('sb.' + blocked))); R.input = null; return; }
  const keep = R.input ? R.input.value : '';
  R.replybar = h('div', { class: 'replybar', hidden: true });
  R.chip = h('div', { class: 'attach-chip', hidden: true });
  R.input = h('textarea', { class: 'input-box', rows: 1, maxlength: 4000, dir: 'auto', placeholder: t('type_message'), 'aria-label': t('type_message'),
    oninput: onInput, onkeydown: onKey, onpaste: (e) => { const f = e.clipboardData?.files?.[0]; if (f) { e.preventDefault(); attach(f); } } });
  R.input.value = keep;
  R.sendBtn = h('button', { class: 'send', type: 'button', 'aria-label': t('send'), onclick: send }, icon('send', 20, 'dir'));
  R.fileIn = h('input', { type: 'file', hidden: true, onchange: () => { if (R.fileIn.files[0]) attach(R.fileIn.files[0]); R.fileIn.value = ''; } });
  clear(R.composer).append(R.replybar, R.chip, h('div', { class: 'crow' },
    iconBtn('smile', t('emoji'), (e) => emojiPicker(e.currentTarget)), iconBtn('sticker', t('stickers'), (e) => stickerPicker(e.currentTarget)),
    iconBtn('clip', t('attach'), () => R.fileIn.click()), R.fileIn, R.input, R.sendBtn));
  renderReplyBar(); renderChip(); autosize();
}
function autosize() { if (!R.input) return; R.input.style.height = 'auto'; R.input.style.height = Math.min(R.input.scrollHeight, 150) + 'px'; }
let lastTyping = 0;
function onInput() {
  autosize();
  const now = Date.now();
  if (S.ws && S.wsUp && now - lastTyping > 2000 && R.input.value.trim()) { lastTyping = now; S.ws.send(JSON.stringify({ t: 'typing', conv: S.activeId })); }
}
function onKey(e) {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !matchMedia('(pointer: coarse)').matches) { e.preventDefault(); send(); }
  else if (e.key === 'Escape') { if (C.edit || C.reply) { cancelCompose(); } }
  else if (e.key === 'ArrowUp' && !R.input.value && !C.edit) { const mine = [...C.msgs].reverse().find((m) => m.sender.id === S.me.id && m.kind === 'text' && !m.deleted); if (mine) { e.preventDefault(); startEdit(mine); } }
}
function cancelCompose() { if (C.edit) R.input.value = ''; C.edit = null; C.reply = null; renderReplyBar(); autosize(); }
export function startReply(m) { C.edit = null; C.reply = m; renderReplyBar(); R.input?.focus(); }
export function startEdit(m) { C.reply = null; C.edit = m; if (!R.input) return; R.input.value = m.body; renderReplyBar(); autosize(); R.input.focus(); }
function renderReplyBar() {
  if (!R.replybar) return;
  const m = C.edit || C.reply; R.replybar.hidden = !m; if (!m) return;
  clear(R.replybar).append(icon(C.edit ? 'edit' : 'reply', 16), h('span', { class: 'rb-body' }, h('b', null, C.edit ? t('editing') : t('replying_to', { n: m.sender.display_name })), h('span', null, m.kind === 'sticker' ? m.body : m.file ? '📎 ' + m.file.name : m.body)), iconBtn('x', t('cancel'), cancelCompose, 'small'));
}
function renderChip() {
  if (!R.chip) return;
  R.chip.hidden = !C.file; if (!C.file) return;
  clear(R.chip).append(icon('file', 18), h('span', null, C.file.name, h('small', null, C.file.uploading ? ' ' + t('uploading') : ' · ' + (C.file.size / 1024 < 1024 ? Math.ceil(C.file.size / 1024) + ' KB' : (C.file.size / 1048576).toFixed(1) + ' MB'))), iconBtn('x', t('remove'), () => { C.file = null; renderChip(); }, 'small'));
}
async function attach(f) {
  if (!R.input) return;
  if (f.size > S.limits.upload) { toast(t('e.too_large', { n: Math.round(S.limits.upload / 1048576) }), 'error'); return; }
  C.file = { name: f.name, size: f.size, uploading: true }; renderChip();
  try { const up = await uploadFile(f, { conv: S.activeId }); C.file = { ...up, uploading: false }; renderChip(); R.input.focus(); }
  catch (e) { C.file = null; renderChip(); toast(errText(e), 'error'); }
}

async function send() {
  const c = conv(); if (!c || !R.input) return;
  const text = R.input.value.trim();
  if (C.edit) {
    const m = C.edit; if (!text) return;
    C.edit = null; R.input.value = ''; renderReplyBar(); autosize();
    if (text !== m.body) try { await api('PATCH', `/api/messages/${m.id}`, { body: text }); } catch (e) { toast(errText(e), 'error'); }
    return;
  }
  if (C.file?.uploading) return;
  if (!text && !C.file) return;
  const body = { body: text, reply_to: C.reply?.id || undefined, file_id: C.file?.id, client_id: uid() };
  const reply = C.reply; C.reply = null; const file = C.file; C.file = null;
  R.input.value = ''; renderReplyBar(); renderChip(); autosize();
  if (C.detached) await jumpLatest();
  const temp = { id: '', kind: 'text', body: text || (file ? file.name : ''), created_at: Date.now(), sender: S.me, reply: reply ? { id: reply.id, name: reply.sender.display_name, body: reply.body, kind: reply.kind } : null, file: file ? { name: file.name, size: file.size, id: file.id, image: false } : null };
  const el = msgEl(temp, { conv: c, pending: true, prev: C.msgs.at(-1) });
  C.pend.set(body.client_id, el); R.list.append(el); toBottom();
  const done = (m) => { if (C.pend.has(body.client_id)) { C.pend.get(body.client_id).remove(); C.pend.delete(body.client_id); } if (m && !C.msgs.some((x) => x.id === m.id)) handleNew(m); };
  try { const r = await api('POST', `/api/conversations/${c.id}/messages`, body); done(r.message); }
  catch (e) {
    el.classList.add('failed'); el.querySelector('.ticks')?.remove();
    el.querySelector('.meta').append(h('button', { class: 'retry', type: 'button', onclick: () => { C.pend.delete(body.client_id); el.remove(); R.input.value = text; R.input.focus(); } }, t('failed_retry')));
    toast(errText(e), 'error');
  }
}
async function sendSticker(s) {
  try { await api('POST', `/api/conversations/${S.activeId}/messages`, { kind: 'sticker', body: s, reply_to: C.reply?.id }); C.reply = null; renderReplyBar(); } catch (e) { toast(errText(e), 'error'); }
}
function emojiPicker(anchor) {
  const grid = h('div', { class: 'emoji-pop' }, Object.entries(EMOJI).map(([k, list]) => h('div', { class: 'ecat' }, h('small', null, t('emo.' + k)), h('div', { class: 'egrid' }, list.map((e) => h('button', { type: 'button', class: 'em', onclick: () => { const i = R.input; const s = i.selectionStart ?? i.value.length; i.setRangeText(e, s, i.selectionEnd ?? s, 'end'); i.focus(); autosize(); } }, e))))));
  popup(anchor, grid, 'pop-emoji');
}
function stickerPicker(anchor) {
  popup(anchor, h('div', { class: 'sticker-pop' }, S.stickers.map((s) => h('button', { type: 'button', class: 'stk', 'aria-label': s, onclick: () => { closeMenu(); sendSticker(s); } }, s))), 'pop-sticker');
}

export const reloadActive = async () => { if (S.activeId && R.list) { await loadMessages(); loadPins(); scheduleRead(); } };
