import { h, icon, avatar, fmtTime, fmtSize, linkify, menu, toast, confirmBox, iconBtn } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks, sysText } from './state.js';
import { reportDialog } from './dialogs.js';

const sameGroup = (a, b) => a && b && a.sender.id === b.sender.id && b.created_at - a.created_at < 5 * 60e3 && new Date(a.created_at).toDateString() === new Date(b.created_at).toDateString() && a.kind !== 'system';

export function tickState(conv, m) {
  if (conv?.type !== 'dm') return null;
  if (m.id <= (conv.peer_read_id || 0)) return 'read';
  if (m.id <= (conv.peer_delivered_id || 0)) return 'delivered';
  return 'sent';
}
export function tickEl(state) {
  const el = h('span', { class: 'ticks ' + state, title: t('st.' + state) }, icon(state === 'sent' ? 'check' : 'check2', 15));
  return el;
}

function bodyEl(m, conv) {
  if (m.deleted) return h('div', { class: 'deleted' }, icon('ban', 15), t('msg_deleted'));
  const out = [];
  if (m.reply) {
    out.push(h('button', { class: 'quote', type: 'button', onclick: () => hooks.jumpTo(m.reply.id) },
      h('b', null, m.reply.name || '—'),
      h('span', null, m.reply.deleted ? t('msg_deleted') : (m.reply.kind === 'sticker' ? m.reply.body : m.reply.kind === 'file' ? '📎 ' + (m.reply.body || t('attachment')) : m.reply.body))));
  }
  if (m.kind === 'sticker') out.push(h('div', { class: 'sticker' }, m.body));
  else if (m.kind === 'meeting') {
    out.push(h('div', { class: 'meet' }, h('span', { class: 'meet-ic' }, icon('video', 22)),
      h('div', null, h('b', null, t('meeting_link')), h('small', null, new URL(m.body).host)),
      h('a', { class: 'btn primary', href: m.body, target: '_blank', rel: 'noopener noreferrer' }, t('join'))));
  } else {
    if (m.file) {
      const url = `/api/files/${m.file.id}`;
      if (m.file.image) out.push(h('a', { class: 'img-att', href: url, target: '_blank', rel: 'noopener' }, h('img', { src: url, alt: m.file.name, loading: 'lazy' })));
      else out.push(h('a', { class: 'file-att', href: url, download: m.file.name },
        h('span', { class: 'file-ic' }, icon('file', 22)),
        h('span', { class: 'file-meta' }, h('b', null, m.file.name), h('small', null, fmtSize(m.file.size) + ' · ' + new Date(m.created_at).toLocaleDateString(document.documentElement.lang, { day: 'numeric', month: 'short', year: 'numeric' }))),
        icon('download', 18)));
    }
    if (m.body) {
      const { frag, urls } = linkify(m.body);
      out.push(h('div', { class: 'text', dir: 'auto' }, frag));
      if (urls[0] && !m.file) { const u = new URL(urls[0]); out.push(h('a', { class: 'linkcard', href: urls[0], target: '_blank', rel: 'noopener noreferrer nofollow' }, icon('link', 16), h('span', null, h('b', null, u.hostname.replace(/^www\./, '')), h('small', null, (u.pathname + u.search).slice(0, 60) || '/')))); }
    }
  }
  return out;
}

export function msgEl(m, { prev, conv, inThread = false, pending = false } = {}) {
  if (m.kind === 'system') return h('div', { class: 'sys', dataset: { id: m.id } }, h('span', null, sysText(m.body)));
  const own = m.sender.id === S.me.id;
  const group = conv?.type === 'group';
  const head = !sameGroup(prev, m);
  const el = h('div', { class: `msg ${own ? 'own' : 'other'}${head ? ' head' : ''}${m.kind === 'sticker' ? ' is-sticker' : ''}${pending ? ' pending' : ''}`, dataset: { id: m.id || '', ts: m.created_at } });
  if (group && !own) el.append(head ? h('span', { class: 'av-slot' }, avatar(m.sender, 32)) : h('span', { class: 'av-slot' }));
  const meta = h('span', { class: 'meta' },
    m.pinned ? h('span', { class: 'pinned-mark', title: t('pinned') }, icon('pin', 12)) : null,
    m.edited_at && !m.deleted ? h('i', null, t('edited')) : null,
    h('time', null, fmtTime(m.created_at)),
    own && !pending && !m.deleted && conv ? (tickState(conv, m) ? tickEl(tickState(conv, m)) : null) : null,
    pending ? h('span', { class: 'ticks sending' }, '…') : null);
  const bubble = h('div', { class: 'bubble' },
    group && !own && head ? h('div', { class: 'sender' }, m.sender.display_name) : null,
    bodyEl(m, conv), meta,
    !inThread && m.thread_count ? h('button', { class: 'thread-link', type: 'button', onclick: () => hooks.openThread(m) }, icon('thread', 14), t('n_replies', { n: m.thread_count })) : null);
  el.append(bubble);
  if (!m.deleted && !pending && m.id) {
    const more = iconBtn('more', t('more'), (e) => showMenu(e.currentTarget, m, conv, inThread), 'msg-more');
    const quick = h('div', { class: 'msg-tools' },
      iconBtn('reply', t('reply'), () => hooks.reply(m)),
      group && !inThread && !m.thread_root ? iconBtn('thread', t('thread'), () => hooks.openThread(m)) : null, more);
    el.append(quick);
  }
  return el;
}

function showMenu(anchor, m, conv, inThread) {
  const own = m.sender.id === S.me.id;
  const myRole = conv?.my.role;
  const admin = myRole === 'owner' || myRole === 'admin';
  menu(anchor, [
    { label: t('reply'), icon: 'reply', onClick: () => hooks.reply(m) },
    conv?.type === 'group' && !inThread && !m.thread_root ? { label: t('reply_thread'), icon: 'thread', onClick: () => hooks.openThread(m) } : null,
    m.body && m.kind !== 'meeting' ? { label: t('copy'), icon: 'copy', onClick: () => navigator.clipboard?.writeText(m.body).then(() => toast(t('copied'), 'success')).catch(() => {}) } : null,
    own && m.kind === 'text' ? { label: t('edit'), icon: 'edit', onClick: () => hooks.edit(m) } : null,
    (conv?.type === 'dm' || admin) ? { label: m.pinned ? t('unpin_msg') : t('pin_msg'), icon: 'pin', onClick: () => api('POST', `/api/messages/${m.id}/pin`, { pinned: !m.pinned }).catch((e) => toast(errText(e), 'error')) } : null,
    { sep: true },
    !own ? { label: t('report'), icon: 'flag', onClick: () => reportDialog('message', m.id) } : null,
    own || (conv?.type === 'group' && admin) ? { label: t('delete'), icon: 'trash', danger: true, onClick: async () => { if (await confirmBox(t('delete_msg_title'), t('delete_msg_text'), t('delete'))) api('DELETE', `/api/messages/${m.id}`).catch((e) => toast(errText(e), 'error')); } } : null,
  ]);
}
