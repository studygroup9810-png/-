'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const U = require('./util');
const mod = require('./moderation');
const { HttpError, str, int } = U;

const STICKERS = ['😀','😂','🥰','😎','🤩','😭','😡','🤔','🙌','👍','👏','🙏','🔥','💯','🎉','❤️','💔','🌹','☕','🍕','🎂','⚽','🚀','🌙'];
const EXT = {
  png: ['image/png', 'img'], jpg: ['image/jpeg', 'img'], jpeg: ['image/jpeg', 'img'], gif: ['image/gif', 'img'], webp: ['image/webp', 'img'],
  pdf: ['application/pdf', 'pdf'], txt: ['text/plain; charset=utf-8', 'text'], md: ['text/plain; charset=utf-8', 'text'], csv: ['text/plain; charset=utf-8', 'text'],
  doc: ['application/msword', 'ole'], xls: ['application/vnd.ms-excel', 'ole'], ppt: ['application/vnd.ms-powerpoint', 'ole'],
  docx: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'zip'],
  xlsx: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'zip'],
  pptx: ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'zip'],
};
function magicOk(kind, ext, b) {
  const h = (n) => b.subarray(0, n);
  switch (kind) {
    case 'img':
      if (ext === 'png') return h(4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]));
      if (ext === 'jpg' || ext === 'jpeg') return h(3).equals(Buffer.from([0xff, 0xd8, 0xff]));
      if (ext === 'gif') return h(4).toString('latin1') === 'GIF8';
      if (ext === 'webp') return h(4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP';
      return false;
    case 'pdf': return h(4).toString('latin1') === '%PDF';
    case 'zip': return h(4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]));
    case 'ole': return h(4).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0]));
    case 'text': return !b.subarray(0, 8192).includes(0);
  }
  return false;
}
const cleanName = (n) => {
  n = String(n || 'file').replace(/[\u0000-\u001f\u007f\\/:*?"<>|]/g, '_').replace(/^\.+/, '').trim();
  return (n || 'file').slice(-120);
};

module.exports = function createApp({ db, rt, config, mailer }) {
  const cache = new Map();
  const P = (sql) => { let s = cache.get(sql); if (!s) { s = db.prepare(sql); cache.set(sql, s); } return s; };
  const limiter = new U.RateLimiter();
  function tx(fn) {
    db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
  }
  const uploadDir = path.join(config.dataDir, 'uploads');
  fs.mkdirSync(uploadDir, { recursive: true });

  // ---------- helpers ----------
  const pub = (u) => u && { id: u.id, username: u.username, display_name: u.deleted ? '—' : u.display_name, avatar_file: u.deleted ? null : u.avatar_file, status_text: u.deleted ? '' : u.status_text, deleted: !!u.deleted };
  const meShape = (u) => ({ id: u.id, email: u.email, username: u.username, display_name: u.display_name, avatar_file: u.avatar_file, status_text: u.status_text, role: u.role, allow_requests: !!u.allow_requests, prefs: safeJson(u.prefs, {}) });
  function safeJson(s, d) { try { return JSON.parse(s); } catch { return d; } }
  const getUser = (id) => P('SELECT * FROM users WHERE id=?').get(id);
  const audit = (actor, action, target, detail) => P('INSERT INTO audit(actor,action,target,detail,created_at) VALUES(?,?,?,?,?)').run(actor, action, target == null ? null : String(target), detail == null ? null : String(detail), Date.now());
  // ---------- moderation: abuse / bullying ----------
  // Runtime settings (set from the admin panel) override the env defaults and survive restarts.
  for (const r of P('SELECT key,value FROM settings').all()) {
    if (r.key === 'moderation' && ['suspend', 'off'].includes(r.value)) config.moderation = r.value;
    if (r.key === 'registration_open') config.registrationOpen = r.value === '1';
    if (r.key === 'suspend_days' && Number(r.value) >= 1) config.suspendDays = Number(r.value);
  }
  const saveSetting = (k, v) => P('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v));
  function liftExpired(u) {
    if (u.suspended_until && u.suspended_until <= Date.now()) {
      P('UPDATE users SET suspended_until=NULL, suspension_at=NULL, suspension_violation=NULL WHERE id=?').run(u.id);
      P("UPDATE violations SET status='expired' WHERE id=? AND status='active'").run(u.suspension_violation);
      return getUser(u.id);
    }
    return u;
  }
  const isSuspended = (u) => !!u.suspended_until && u.suspended_until > Date.now();
  function suspensionInfo(u) {
    if (!isSuspended(u)) return null;
    const v = P('SELECT * FROM violations WHERE id=?').get(u.suspension_violation);
    const a = v && P('SELECT * FROM appeals WHERE violation_id=?').get(v.id);
    return {
      suspended_at: u.suspension_at, suspended_until: u.suspended_until, days: config.suspendDays,
      violation: v && { id: v.id, context: v.context, category: v.category, text: v.text, created_at: v.created_at },
      appeal: a ? { id: a.id, status: a.status, text: a.text, response: a.response, created_at: a.created_at, handled_at: a.handled_at } : null,
      can_appeal: !!v && !a,
    };
  }
  /** Throws if `text` is abusive. Existing users are suspended from the first confirmed violation. */
  function guardText(user, text, context) {
    if (config.moderation === 'off' || !text) return;
    const hit = mod.check(text);
    if (!hit) return;
    const t = Date.now();
    if (user.role === 'admin') { audit(user.id, 'content.blocked', context, hit.category); throw new HttpError(403, 'content_violation', { category: hit.category, suspended_until: null }); }
    const until = t + config.suspendDays * 864e5;
    const vid = tx(() => {
      const r = P('INSERT INTO violations(user_id,context,category,term,text,created_at,suspended_until) VALUES(?,?,?,?,?,?,?)').run(user.id, context, hit.category, hit.term, String(text).slice(0, 500), t, until);
      P('UPDATE users SET suspended_until=?, suspension_at=?, suspension_violation=? WHERE id=?').run(until, t, r.lastInsertRowid, user.id);
      return r.lastInsertRowid;
    });
    audit(null, 'user.auto_suspend', user.username, `${hit.category} in ${context} (violation #${vid})`);
    rt.kickUser(user.id);
    mailer({ to: user.email, subject: 'FriendSpace — account suspended / تم إيقاف حسابك', text: `Your account is suspended for ${config.suspendDays} days (until ${new Date(until).toISOString()}) because a message violated our rules against abuse and bullying. You can appeal after signing in.\n\nتم إيقاف حسابك لمدة ${config.suspendDays} أيام (حتى ${new Date(until).toISOString()}) بسبب محتوى مخالف لقواعد منع الإساءة والتنمر. يمكنك الاعتراض بعد تسجيل الدخول.` }).catch(() => {});
    throw new HttpError(403, 'content_violation', { category: hit.category, suspended_until: until });
  }
  const pair = (a, b) => (a < b ? [a, b] : [b, a]);
  const friendship = (a, b) => { const [x, y] = pair(a, b); return P('SELECT * FROM friendships WHERE user_a=? AND user_b=?').get(x, y); };
  const areFriends = (a, b) => friendship(a, b)?.status === 'accepted';
  const blockedEither = (a, b) => !!P('SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)').get(a, b, b, a);
  const getConv = (id) => P('SELECT * FROM conversations WHERE id=?').get(id);
  const getMember = (cid, uid) => P('SELECT * FROM members WHERE conv_id=? AND user_id=?').get(cid, uid);
  const isAdminRole = (m) => m && (m.role === 'owner' || m.role === 'admin');
  function requireMember(cid, uid) {
    const m = getMember(cid, uid);
    if (!m) throw new HttpError(404, 'not_found');
    return m;
  }
  const peerOf = (cid, uid) => P('SELECT u.* FROM members m JOIN users u ON u.id=m.user_id WHERE m.conv_id=? AND m.user_id!=?').get(cid, uid);

  function sendBlockReason(conv, me, mem) {
    if (conv.type === 'group') return conv.post_policy === 'admins' && !isAdminRole(mem) ? 'admins_only' : null;
    const peer = peerOf(conv.id, me);
    if (!peer || peer.deleted || peer.disabled) return 'peer_unavailable';
    if (blockedEither(me, peer.id)) return 'blocked';
    if (!areFriends(me, peer.id)) return 'not_friends';
    return null;
  }

  function summarizeConv(cid, uid) {
    const c = getConv(cid), m = getMember(cid, uid);
    if (!c || !m) return null;
    const last = P('SELECT m.id,m.sender_id,m.kind,m.body,m.created_at,m.deleted_at,m.file_id FROM messages m WHERE m.conv_id=? ORDER BY m.id DESC LIMIT 1').get(cid);
    const unread = P(`SELECT COUNT(*) n FROM messages WHERE conv_id=? AND id>? AND sender_id!=? AND deleted_at IS NULL AND kind!='system'`).get(cid, m.last_read_id, uid).n;
    const out = {
      id: c.id, type: c.type, name: c.name, description: c.description, avatar_file: c.avatar_file, is_public: !!c.is_public,
      post_policy: c.post_policy, add_policy: c.add_policy, created_at: c.created_at,
      my: { role: m.role, pinned: !!m.pinned, muted: !!m.muted, archived: !!m.archived, last_read_id: m.last_read_id },
      unread, last_message: last ? { id: last.id, sender_id: last.sender_id, kind: last.kind, body: last.deleted_at ? '' : (last.kind === 'file' && !last.body ? '' : last.body.slice(0, 120)), created_at: last.created_at, deleted: !!last.deleted_at } : null,
      last_at: last ? last.created_at : c.created_at,
      member_count: P('SELECT COUNT(*) n FROM members WHERE conv_id=?').get(cid).n,
      send_block: sendBlockReason(c, uid, m),
    };
    if (c.type === 'dm') {
      const peer = peerOf(cid, uid);
      out.peer = pub(peer);
      const pm = getMember(cid, peer.id);
      out.peer_read_id = pm.last_read_id; out.peer_delivered_id = pm.delivered_id;
    }
    return out;
  }
  const pushConv = (cid, uids) => { for (const uid of uids || rt.memberIds(cid)) { const s = summarizeConv(cid, uid); if (s) rt.toUser(uid, { t: 'conv', conv: s }); } };
  /** Presence is normally pushed when someone connects; call this when people become peers (friend accepted, joined a space). */
  function syncPresence(uids) {
    const ids = [...new Set(uids)];
    for (const a of ids) for (const b of ids) if (a !== b && rt.isOnline(b)) rt.toUser(a, { t: 'presence', user_id: b, online: true, last_seen: Date.now() });
  }
  const pushFriends = (...uids) => { for (const u of uids) rt.toUser(u, { t: 'friends' }); };

  const MSG_SQL = `SELECT m.*, u.username su, u.display_name sdn, u.avatar_file sav, u.deleted sdel,
      f.name fname, f.mime fmime, f.size fsize,
      (SELECT COUNT(*) FROM messages t WHERE t.thread_root=m.id AND t.deleted_at IS NULL) AS thread_count,
      r.body rbody, r.sender_id rsender, r.deleted_at rdel, r.kind rkind, ru.display_name rname
    FROM messages m JOIN users u ON u.id=m.sender_id
    LEFT JOIN files f ON f.id=m.file_id
    LEFT JOIN messages r ON r.id=m.reply_to LEFT JOIN users ru ON ru.id=r.sender_id`;
  function shapeMsg(r) {
    const del = !!r.deleted_at;
    return {
      id: r.id, conv_id: r.conv_id, kind: r.kind, body: del ? '' : r.body, deleted: del, pinned: !!r.pinned,
      created_at: r.created_at, edited_at: r.edited_at, reply_to: r.reply_to, thread_root: r.thread_root, thread_count: r.thread_count,
      sender: { id: r.sender_id, username: r.su, display_name: r.sdel ? '—' : r.sdn, avatar_file: r.sdel ? null : r.sav },
      reply: r.reply_to ? { id: r.reply_to, name: r.rname, kind: r.rkind, deleted: !!r.rdel, body: r.rdel ? '' : String(r.rbody || '').slice(0, 100) } : null,
      file: r.file_id && !del ? { id: r.file_id, name: r.fname, mime: r.fmime, size: r.fsize, image: String(r.fmime).startsWith('image/') } : null,
    };
  }
  const loadMsg = (id) => { const r = P(MSG_SQL + ' WHERE m.id=?').get(id); return r ? shapeMsg(r) : null; };

  function systemMessage(cid, actor, event, extra = {}) {
    const res = P('INSERT INTO messages(conv_id,sender_id,kind,body,created_at) VALUES(?,?,?,?,?)').run(cid, actor, 'system', JSON.stringify({ e: event, ...extra }), Date.now());
    const msg = loadMsg(res.lastInsertRowid);
    rt.toConv(cid, { t: 'message.new', msg });
    return msg;
  }

  function createDm(a, b) {
    const [x, y] = pair(a, b); const key = x + ':' + y;
    const ex = P('SELECT id FROM conversations WHERE dm_key=?').get(key);
    if (ex) return ex.id;
    const t = Date.now();
    const r = P("INSERT INTO conversations(type,dm_key,created_by,created_at) VALUES('dm',?,?,?)").run(key, a, t);
    P('INSERT INTO members(conv_id,user_id,joined_at) VALUES(?,?,?)').run(r.lastInsertRowid, a, t);
    P('INSERT INTO members(conv_id,user_id,joined_at) VALUES(?,?,?)').run(r.lastInsertRowid, b, t);
    return r.lastInsertRowid;
  }

  // ---------- auth ----------
  const COOKIE = 'fs_session';
  const ip = (req) => config.trustProxy ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress : req.socket.remoteAddress;
  const isSecure = (req) => config.cookieSecure === 'auto' ? (config.publicUrl.startsWith('https') || (config.trustProxy && req.headers['x-forwarded-proto'] === 'https')) : config.cookieSecure === '1';
  const cookieStr = (req, token, maxAge) => `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isSecure(req) ? '; Secure' : ''}`;

  function authenticate(req) {
    const tok = U.parseCookies(req.headers.cookie)[COOKIE];
    if (!tok) return null;
    const s = P('SELECT * FROM sessions WHERE token_hash=?').get(U.sha256(tok));
    if (!s || s.expires_at < Date.now()) return null;
    let u = getUser(s.user_id);
    if (!u || u.disabled || u.deleted) return null;
    u = liftExpired(u);
    const t = Date.now();
    if (t - s.last_used > 60000) P('UPDATE sessions SET last_used=?, expires_at=? WHERE id=?').run(t, t + config.sessionDays * 864e5, s.id);
    return { user: u, sessionId: s.id, suspended: isSuspended(u) };
  }
  function createSession(req, res, uid) {
    const token = U.randomToken(32); const t = Date.now();
    P('INSERT INTO sessions(user_id,token_hash,ua,ip,created_at,last_used,expires_at) VALUES(?,?,?,?,?,?,?)')
      .run(uid, U.sha256(token), String(req.headers['user-agent'] || '').slice(0, 200), ip(req), t, t, t + config.sessionDays * 864e5);
    res.setHeader('Set-Cookie', cookieStr(req, token, config.sessionDays * 86400));
  }
  let dummyP = U.hashPassword('dummy-password-for-timing');

  const validEmail = (e) => /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(e) && e.length <= 254;
  const validUsername = (u) => /^[a-z0-9_.]{3,24}$/.test(u);
  const validPassword = (p) => typeof p === 'string' && p.length >= 8 && p.length <= 128 && /[A-Za-z؀-ۿ]/.test(p) && /\d/.test(p);

  // ---------- route table ----------
  const routes = [];
  const R = (method, pattern, opts, fn) => {
    if (typeof opts === 'function') { fn = opts; opts = {}; }
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, opts, fn });
  };
  const needRole = (ctx, ...roles) => { if (!roles.includes(ctx.user.role)) throw new HttpError(403, 'forbidden'); };

  R('GET', '/api/health', { auth: false }, () => ({ ok: true }));

  R('POST', '/api/auth/register', { auth: false }, async (c) => {
    if (!config.registrationOpen) throw new HttpError(403, 'registration_closed');
    if (!limiter.hit('reg:' + c.ip, 20, 3600e3)) throw new HttpError(429, 'rate_limited');
    const b = c.body;
    const email = str(b.email, 254).toLowerCase(), username = str(b.username, 24).toLowerCase(), dn = str(b.display_name, 40);
    if (!validEmail(email)) throw new HttpError(400, 'invalid_email');
    if (!validUsername(username)) throw new HttpError(400, 'invalid_username');
    if (!dn) throw new HttpError(400, 'invalid_name');
    if (!validPassword(b.password) || b.password.toLowerCase().includes(username)) throw new HttpError(400, 'weak_password');
    if (config.moderation !== 'off' && (mod.check(dn) || mod.check(username.replace(/[_.]/g, ' ')))) throw new HttpError(400, 'inappropriate_content');
    if (P('SELECT 1 FROM users WHERE email=?').get(email)) throw new HttpError(409, 'email_taken');
    if (P('SELECT 1 FROM users WHERE username=?').get(username)) throw new HttpError(409, 'username_taken');
    const hash = await U.hashPassword(b.password);
    const first = P('SELECT COUNT(*) n FROM users').get().n === 0;
    const role = first || (config.adminEmail && email === config.adminEmail) ? 'admin' : 'user';
    let id;
    try { id = P('INSERT INTO users(email,username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?,?)').run(email, username, dn, hash, role, Date.now()).lastInsertRowid; }
    catch { throw new HttpError(409, 'username_taken'); }
    createSession(c.req, c.res, id);
    return { user: meShape(getUser(id)) };
  });

  R('POST', '/api/auth/login', { auth: false }, async (c) => {
    const ident = str(c.body.identifier, 254).toLowerCase(); const pw = typeof c.body.password === 'string' ? c.body.password : '';
    if (!ident || !pw) throw new HttpError(400, 'invalid_credentials');
    if (!limiter.hit('login-ip:' + c.ip, 40, 600e3)) throw new HttpError(429, 'rate_limited');
    const lockKey = 'login-fail:' + ident + ':' + c.ip;
    if (limiter.count(lockKey) >= 5) throw new HttpError(429, 'too_many_attempts');
    const u = P('SELECT * FROM users WHERE (email=? OR username=?) AND deleted=0').get(ident, ident);
    const ok = u ? await U.verifyPassword(pw, u.password_hash) : (await U.verifyPassword(pw, await dummyP), false);
    if (!ok) { limiter.hit(lockKey, 1e9, 900e3); throw new HttpError(401, 'invalid_credentials'); }
    if (u.disabled) throw new HttpError(403, 'account_disabled');
    limiter.clear(lockKey);
    createSession(c.req, c.res, u.id);
    const fresh = liftExpired(getUser(u.id));
    return { user: meShape(fresh), suspension: suspensionInfo(fresh) };
  });

  R('POST', '/api/auth/logout', { allowSuspended: true }, (c) => {
    P('DELETE FROM sessions WHERE id=?').run(c.sessionId);
    rt.kickSession(c.sessionId);
    c.res.setHeader('Set-Cookie', cookieStr(c.req, '', 0));
    return { ok: true };
  });
  R('POST', '/api/auth/logout-all', { allowSuspended: true }, (c) => {
    P('DELETE FROM sessions WHERE user_id=?').run(c.user.id);
    rt.kickUser(c.user.id);
    c.res.setHeader('Set-Cookie', cookieStr(c.req, '', 0));
    return { ok: true };
  });

  R('POST', '/api/auth/forgot', { auth: false }, async (c) => {
    if (!limiter.hit('forgot:' + c.ip, 10, 3600e3)) throw new HttpError(429, 'rate_limited');
    const email = str(c.body.email, 254).toLowerCase();
    const u = validEmail(email) ? P('SELECT * FROM users WHERE email=? AND disabled=0 AND deleted=0').get(email) : null;
    if (u && limiter.hit('forgot-user:' + u.id, 3, 3600e3)) {
      const token = U.randomToken(32);
      P('INSERT INTO reset_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)').run(U.sha256(token), u.id, Date.now() + 3600e3);
      const link = `${config.publicUrl}/?reset=${token}`;
      mailer({ to: u.email, subject: 'FriendSpace — password reset / استعادة كلمة المرور', text: `Reset your password (valid 1 hour):\n${link}\n\nلاستعادة كلمة المرور (صالح لمدة ساعة):\n${link}\n\nIf you did not request this, ignore this message.` }).catch((e) => console.error('mail failed:', e.message));
    }
    return { ok: true }; // identical response whether or not the account exists
  });
  R('POST', '/api/auth/reset', { auth: false }, async (c) => {
    if (!limiter.hit('reset:' + c.ip, 20, 3600e3)) throw new HttpError(429, 'rate_limited');
    const tok = str(c.body.token, 200);
    const row = P('SELECT * FROM reset_tokens WHERE token_hash=? AND used=0 AND expires_at>?').get(U.sha256(tok), Date.now());
    if (!row) throw new HttpError(400, 'invalid_token');
    const u = getUser(row.user_id);
    if (!validPassword(c.body.password) || c.body.password.toLowerCase().includes(u.username)) throw new HttpError(400, 'weak_password');
    const hash = await U.hashPassword(c.body.password);
    tx(() => {
      P('UPDATE users SET password_hash=? WHERE id=?').run(hash, u.id);
      P('UPDATE reset_tokens SET used=1 WHERE user_id=?').run(u.id);
      P('DELETE FROM sessions WHERE user_id=?').run(u.id);
    });
    rt.kickUser(u.id);
    return { ok: true };
  });

  // ---------- me ----------
  R('GET', '/api/me', { allowSuspended: true }, (c) => ({ user: meShape(c.user), suspension: suspensionInfo(c.user) }));
  R('GET', '/api/suspension', { allowSuspended: true }, (c) => ({ suspension: suspensionInfo(c.user) }));
  R('POST', '/api/appeals', { allowSuspended: true }, (c) => {
    const info = suspensionInfo(c.user);
    if (!info || !info.violation) throw new HttpError(400, 'not_suspended');
    if (!info.can_appeal) throw new HttpError(409, 'already_appealed');
    const text = str(c.body.text, 1000);
    if (text.length < 10) throw new HttpError(400, 'appeal_too_short');
    if (!limiter.hit('appeal:' + c.user.id, 5, 3600e3)) throw new HttpError(429, 'rate_limited');
    P('INSERT INTO appeals(violation_id,user_id,text,created_at) VALUES(?,?,?,?)').run(info.violation.id, c.user.id, text, Date.now());
    audit(c.user.id, 'appeal.create', c.user.username, 'violation #' + info.violation.id);
    return { suspension: suspensionInfo(getUser(c.user.id)) };
  });
  R('PATCH', '/api/me', (c) => {
    const b = c.body, u = c.user;
    const dn = b.display_name !== undefined ? str(b.display_name, 40) : u.display_name;
    if (!dn) throw new HttpError(400, 'invalid_name');
    const status = b.status_text !== undefined ? str(b.status_text, 80) : u.status_text;
    if (dn !== u.display_name) guardText(u, dn, 'display_name');
    if (status !== u.status_text) guardText(u, status, 'status');
    const allow = b.allow_requests !== undefined ? (b.allow_requests ? 1 : 0) : u.allow_requests;
    let avatar = u.avatar_file;
    if (b.avatar_file !== undefined) {
      if (b.avatar_file === null) avatar = null;
      else {
        const f = P("SELECT * FROM files WHERE id=? AND uploader=? AND purpose='avatar'").get(int(b.avatar_file), u.id);
        if (!f) throw new HttpError(400, 'invalid_file');
        avatar = f.id; P('UPDATE files SET attached=1 WHERE id=?').run(f.id);
      }
    }
    let prefs = safeJson(u.prefs, {});
    if (b.prefs && typeof b.prefs === 'object') {
      if (['light', 'dark', 'system'].includes(b.prefs.theme)) prefs.theme = b.prefs.theme;
      if (['ar', 'en'].includes(b.prefs.lang)) prefs.lang = b.prefs.lang;
    }
    P('UPDATE users SET display_name=?, status_text=?, allow_requests=?, avatar_file=?, prefs=? WHERE id=?').run(dn, status, allow, avatar, JSON.stringify(prefs), u.id);
    const nu = getUser(u.id);
    rt.toUser(u.id, { t: 'me.update', me: meShape(nu) });
    rt.toUsers(rt.peersOf(u.id), { t: 'user.update', user: pub(nu) });
    return { user: meShape(nu) };
  });
  R('POST', '/api/me/password', async (c) => {
    if (!limiter.hit('chpw:' + c.user.id, 10, 3600e3)) throw new HttpError(429, 'rate_limited');
    if (!(await U.verifyPassword(String(c.body.current || ''), c.user.password_hash))) throw new HttpError(403, 'wrong_password');
    if (!validPassword(c.body.next) || c.body.next.toLowerCase().includes(c.user.username)) throw new HttpError(400, 'weak_password');
    const hash = await U.hashPassword(c.body.next);
    P('UPDATE users SET password_hash=? WHERE id=?').run(hash, c.user.id);
    P('DELETE FROM sessions WHERE user_id=? AND id!=?').run(c.user.id, c.sessionId);
    rt.kickUserExceptSession(c.user.id, c.sessionId);
    return { ok: true };
  });

  // ---------- bootstrap / friends ----------
  function friendsPayload(uid) {
    const rows = P('SELECT * FROM friendships WHERE user_a=? OR user_b=?').all(uid, uid);
    const friends = [], incoming = [], outgoing = [];
    for (const r of rows) {
      const other = getUser(r.user_a === uid ? r.user_b : r.user_a);
      if (!other || other.deleted) continue;
      if (r.status === 'accepted') friends.push(pub(other));
      else if (r.requested_by === uid) outgoing.push({ id: r.id, user: pub(other) });
      else incoming.push({ id: r.id, user: pub(other) });
    }
    const blocked = P('SELECT u.* FROM blocks b JOIN users u ON u.id=b.blocked WHERE b.blocker=?').all(uid).map(pub);
    return { friends, incoming, outgoing, blocked };
  }
  R('GET', '/api/friends', (c) => friendsPayload(c.user.id));
  R('GET', '/api/bootstrap', (c) => {
    const uid = c.user.id;
    const ids = P('SELECT conv_id FROM members WHERE user_id=?').all(uid).map((r) => r.conv_id);
    const conversations = ids.map((id) => summarizeConv(id, uid)).filter(Boolean);
    const peers = new Set(rt.peersOf(uid));
    return { me: meShape(c.user), conversations, ...friendsPayload(uid), online: rt.onlineIds().filter((i) => peers.has(i)), stickers: STICKERS, limits: { upload: config.maxUpload, avatar: config.maxAvatar }, meeting: !!config.meetingBase, serverTime: Date.now() };
  });

  R('POST', '/api/friends/request', (c) => {
    if (!limiter.hit('freq:' + c.user.id, 30, 3600e3)) throw new HttpError(429, 'rate_limited');
    const uname = str(c.body.username, 40).toLowerCase().replace(/^@/, '');
    const t = P('SELECT * FROM users WHERE username=? AND deleted=0 AND disabled=0').get(uname);
    if (!t || blockedEither(c.user.id, t.id)) throw new HttpError(404, 'user_not_found');
    if (t.id === c.user.id) throw new HttpError(400, 'self_request');
    const f = friendship(c.user.id, t.id);
    if (f?.status === 'accepted') throw new HttpError(409, 'already_friends');
    if (f && f.requested_by === c.user.id) throw new HttpError(409, 'already_requested');
    if (f && f.requested_by === t.id) return acceptFriendship(f, c.user.id);
    if (!t.allow_requests) throw new HttpError(403, 'requests_disabled');
    const [x, y] = pair(c.user.id, t.id);
    P("INSERT INTO friendships(user_a,user_b,status,requested_by,created_at) VALUES(?,?, 'pending', ?, ?)").run(x, y, c.user.id, Date.now());
    pushFriends(c.user.id, t.id);
    rt.toUser(t.id, { t: 'notify', kind: 'friend_request', from: pub(c.user) });
    return { ok: true, status: 'pending' };
  });
  function acceptFriendship(f, me) {
    const other = f.user_a === me ? f.user_b : f.user_a;
    let cid;
    tx(() => { P("UPDATE friendships SET status='accepted' WHERE id=?").run(f.id); cid = createDm(me, other); });
    pushFriends(me, other); pushConv(cid); syncPresence([me, other]);
    return { ok: true, status: 'accepted', conv_id: cid };
  }
  R('POST', '/api/friends/:id/accept', (c) => {
    const f = P("SELECT * FROM friendships WHERE id=? AND status='pending'").get(int(c.params.id));
    if (!f || f.requested_by === c.user.id || (f.user_a !== c.user.id && f.user_b !== c.user.id)) throw new HttpError(404, 'not_found');
    if (blockedEither(f.user_a, f.user_b)) throw new HttpError(403, 'blocked');
    return acceptFriendship(f, c.user.id);
  });
  R('POST', '/api/friends/:id/decline', (c) => { // decline incoming or cancel outgoing
    const f = P("SELECT * FROM friendships WHERE id=? AND status='pending'").get(int(c.params.id));
    if (!f || (f.user_a !== c.user.id && f.user_b !== c.user.id)) throw new HttpError(404, 'not_found');
    P('DELETE FROM friendships WHERE id=?').run(f.id);
    pushFriends(f.user_a, f.user_b);
    return { ok: true };
  });
  R('DELETE', '/api/friends/:userId', (c) => {
    const other = int(c.params.userId);
    const f = other && friendship(c.user.id, other);
    if (!f || f.status !== 'accepted') throw new HttpError(404, 'not_found');
    P('DELETE FROM friendships WHERE id=?').run(f.id);
    pushFriends(c.user.id, other);
    const dm = P('SELECT id FROM conversations WHERE dm_key=?').get(pair(c.user.id, other).join(':'));
    if (dm) pushConv(dm.id);
    return { ok: true };
  });
  R('POST', '/api/blocks', (c) => {
    const other = int(c.body.user_id);
    const t = other && getUser(other);
    if (!t || t.id === c.user.id) throw new HttpError(404, 'user_not_found');
    P('INSERT OR IGNORE INTO blocks(blocker,blocked,created_at) VALUES(?,?,?)').run(c.user.id, t.id, Date.now());
    const f = friendship(c.user.id, t.id);
    if (f) P('DELETE FROM friendships WHERE id=?').run(f.id);
    pushFriends(c.user.id, t.id);
    const dm = P('SELECT id FROM conversations WHERE dm_key=?').get(pair(c.user.id, t.id).join(':'));
    if (dm) pushConv(dm.id);
    return { ok: true };
  });
  R('DELETE', '/api/blocks/:userId', (c) => {
    const other = int(c.params.userId);
    P('DELETE FROM blocks WHERE blocker=? AND blocked=?').run(c.user.id, other);
    pushFriends(c.user.id);
    const dm = P('SELECT id FROM conversations WHERE dm_key=?').get(pair(c.user.id, other).join(':'));
    if (dm) pushConv(dm.id);
    return { ok: true };
  });

  // ---------- conversations ----------
  R('POST', '/api/conversations/dm', (c) => {
    const other = int(c.body.user_id);
    if (!other || other === c.user.id || !areFriends(c.user.id, other) || blockedEither(c.user.id, other)) throw new HttpError(403, 'not_friends');
    const cid = tx(() => createDm(c.user.id, other));
    pushConv(cid);
    return { conv: summarizeConv(cid, c.user.id) };
  });

  R('POST', '/api/conversations/group', (c) => {
    if (!limiter.hit('mkgroup:' + c.user.id, 20, 3600e3)) throw new HttpError(429, 'rate_limited');
    const name = str(c.body.name, 60); if (!name) throw new HttpError(400, 'invalid_name');
    const desc = str(c.body.description, 300);
    guardText(c.user, name, 'group_name'); guardText(c.user, desc, 'group_description');
    const ids = [...new Set((Array.isArray(c.body.member_ids) ? c.body.member_ids : []).map(int).filter((x) => x && x !== c.user.id))].slice(0, 200);
    for (const id of ids) if (!areFriends(c.user.id, id) || blockedEither(c.user.id, id)) throw new HttpError(403, 'not_friends');
    let avatar = null;
    if (c.body.avatar_file) {
      const f = P("SELECT * FROM files WHERE id=? AND uploader=? AND purpose='avatar'").get(int(c.body.avatar_file), c.user.id);
      if (!f) throw new HttpError(400, 'invalid_file'); avatar = f.id; P('UPDATE files SET attached=1 WHERE id=?').run(f.id);
    }
    const t = Date.now();
    const cid = tx(() => {
      const r = P("INSERT INTO conversations(type,name,description,avatar_file,is_public,created_by,created_at) VALUES('group',?,?,?,?,?,?)").run(name, desc, avatar, c.body.is_public ? 1 : 0, c.user.id, t);
      const id = r.lastInsertRowid;
      P("INSERT INTO members(conv_id,user_id,role,joined_at) VALUES(?,?, 'owner', ?)").run(id, c.user.id, t);
      for (const m of ids) P('INSERT INTO members(conv_id,user_id,joined_at) VALUES(?,?,?)').run(id, m, t);
      return id;
    });
    systemMessage(cid, c.user.id, 'created', { u: c.user.id, n: c.user.display_name });
    pushConv(cid); syncPresence(rt.memberIds(cid));
    return { conv: summarizeConv(cid, c.user.id) };
  });

  R('GET', '/api/conversations/:id', (c) => {
    const cid = int(c.params.id); requireMember(cid, c.user.id);
    const conv = summarizeConv(cid, c.user.id);
    const members = P(`SELECT u.*, m.role mrole FROM members m JOIN users u ON u.id=m.user_id WHERE m.conv_id=?
       ORDER BY CASE m.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, u.display_name`).all(cid).map((u) => ({ ...pub(u), role: u.mrole }));
    return { conv, members };
  });

  R('PATCH', '/api/conversations/:id', (c) => {
    const cid = int(c.params.id); const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    if (conv.type !== 'group') throw new HttpError(400, 'not_group');
    if (!isAdminRole(m)) throw new HttpError(403, 'forbidden');
    const b = c.body; const name = b.name !== undefined ? str(b.name, 60) : conv.name;
    if (!name) throw new HttpError(400, 'invalid_name');
    const desc = b.description !== undefined ? str(b.description, 300) : conv.description;
    if (name !== conv.name) guardText(c.user, name, 'group_name');
    if (desc !== conv.description) guardText(c.user, desc, 'group_description');
    const post = ['all', 'admins'].includes(b.post_policy) ? b.post_policy : conv.post_policy;
    const add = ['all', 'admins'].includes(b.add_policy) ? b.add_policy : conv.add_policy;
    let pubFlag = conv.is_public;
    if (b.is_public !== undefined) { if (m.role !== 'owner') throw new HttpError(403, 'forbidden'); pubFlag = b.is_public ? 1 : 0; }
    let avatar = conv.avatar_file;
    if (b.avatar_file !== undefined) {
      if (b.avatar_file === null) avatar = null;
      else { const f = P("SELECT * FROM files WHERE id=? AND uploader=? AND purpose='avatar'").get(int(b.avatar_file), c.user.id); if (!f) throw new HttpError(400, 'invalid_file'); avatar = f.id; P('UPDATE files SET attached=1 WHERE id=?').run(f.id); }
    }
    P('UPDATE conversations SET name=?,description=?,post_policy=?,add_policy=?,is_public=?,avatar_file=? WHERE id=?').run(name, desc, post, add, pubFlag, avatar, cid);
    if (name !== conv.name) systemMessage(cid, c.user.id, 'renamed', { u: c.user.id, n: c.user.display_name, name });
    pushConv(cid);
    return { conv: summarizeConv(cid, c.user.id) };
  });

  R('PATCH', '/api/conversations/:id/me', (c) => {
    const cid = int(c.params.id); requireMember(cid, c.user.id);
    for (const k of ['pinned', 'muted', 'archived']) if (c.body[k] !== undefined) P(`UPDATE members SET ${k}=? WHERE conv_id=? AND user_id=?`).run(c.body[k] ? 1 : 0, cid, c.user.id);
    pushConv(cid, [c.user.id]);
    return { conv: summarizeConv(cid, c.user.id) };
  });

  R('POST', '/api/conversations/:id/members', (c) => {
    const cid = int(c.params.id); const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    if (conv.type !== 'group') throw new HttpError(400, 'not_group');
    if (conv.add_policy === 'admins' && !isAdminRole(m)) throw new HttpError(403, 'forbidden');
    const ids = [...new Set((Array.isArray(c.body.user_ids) ? c.body.user_ids : [c.body.user_id]).map(int).filter(Boolean))].slice(0, 100);
    const added = [];
    for (const id of ids) {
      const u = getUser(id);
      if (!u || u.deleted || u.disabled || getMember(cid, id)) continue;
      if (!areFriends(c.user.id, id) || blockedEither(c.user.id, id)) throw new HttpError(403, 'not_friends');
      P('INSERT INTO members(conv_id,user_id,joined_at) VALUES(?,?,?)').run(cid, id, Date.now());
      added.push(u);
    }
    for (const u of added) systemMessage(cid, c.user.id, 'added', { u: u.id, n: u.display_name, by: c.user.display_name });
    pushConv(cid); syncPresence(rt.memberIds(cid));
    return { added: added.length };
  });

  function removeMember(cid, uid, kind, actor) {
    const u = getUser(uid);
    P('DELETE FROM members WHERE conv_id=? AND user_id=?').run(cid, uid);
    rt.toUser(uid, { t: 'conv.remove', conv: cid });
    systemMessage(cid, actor, kind, { u: uid, n: u.display_name, by: getUser(actor).display_name });
    pushConv(cid);
  }
  R('DELETE', '/api/conversations/:id/members/:uid', (c) => {
    const cid = int(c.params.id), target = int(c.params.uid);
    const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    if (conv.type !== 'group') throw new HttpError(400, 'not_group');
    const tm = getMember(cid, target); if (!tm) throw new HttpError(404, 'not_found');
    if (target === c.user.id) throw new HttpError(400, 'use_leave');
    if (!isAdminRole(m) || tm.role === 'owner' || (tm.role === 'admin' && m.role !== 'owner')) throw new HttpError(403, 'forbidden');
    removeMember(cid, target, 'removed', c.user.id);
    return { ok: true };
  });
  R('PATCH', '/api/conversations/:id/members/:uid', (c) => { // change role: owner only
    const cid = int(c.params.id), target = int(c.params.uid);
    const m = requireMember(cid, c.user.id); const tm = getMember(cid, target);
    if (m.role !== 'owner') throw new HttpError(403, 'forbidden');
    if (!tm || tm.role === 'owner' || target === c.user.id) throw new HttpError(400, 'invalid');
    const role = c.body.role === 'admin' ? 'admin' : 'member';
    P('UPDATE members SET role=? WHERE conv_id=? AND user_id=?').run(role, cid, target);
    systemMessage(cid, c.user.id, role === 'admin' ? 'promoted' : 'demoted', { u: target, n: getUser(target).display_name });
    pushConv(cid);
    return { ok: true };
  });
  R('POST', '/api/conversations/:id/leave', (c) => {
    const cid = int(c.params.id); const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    if (conv.type !== 'group') throw new HttpError(400, 'not_group');
    const others = P('SELECT * FROM members WHERE conv_id=? AND user_id!=? ORDER BY CASE role WHEN \'admin\' THEN 0 ELSE 1 END, joined_at').all(cid, c.user.id);
    if (!others.length) { // last member: delete the group
      deleteConversation(cid); return { ok: true, deleted: true };
    }
    if (m.role === 'owner') P("UPDATE members SET role='owner' WHERE conv_id=? AND user_id=?").run(cid, others[0].user_id); // ownership passes on
    removeMember(cid, c.user.id, 'left', c.user.id);
    return { ok: true };
  });
  function deleteConversation(cid) {
    const ids = rt.memberIds(cid);
    const files = P('SELECT stored FROM files WHERE conv_id=?').all(cid);
    P('DELETE FROM files WHERE conv_id=?').run(cid);
    P('DELETE FROM conversations WHERE id=?').run(cid);
    for (const f of files) fs.unlink(path.join(uploadDir, f.stored), () => {});
    rt.toUsers(ids, { t: 'conv.remove', conv: cid });
  }
  R('DELETE', '/api/conversations/:id', (c) => {
    const cid = int(c.params.id); const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    if (conv.type !== 'group' || m.role !== 'owner') throw new HttpError(403, 'forbidden');
    deleteConversation(cid);
    return { ok: true };
  });
  R('POST', '/api/conversations/:id/join', (c) => {
    const cid = int(c.params.id); const conv = getConv(cid);
    if (!conv || conv.type !== 'group' || !conv.is_public) throw new HttpError(404, 'not_found');
    if (!getMember(cid, c.user.id)) {
      P('INSERT INTO members(conv_id,user_id,joined_at) VALUES(?,?,?)').run(cid, c.user.id, Date.now());
      systemMessage(cid, c.user.id, 'joined', { u: c.user.id, n: c.user.display_name });
      pushConv(cid); syncPresence(rt.memberIds(cid));
    }
    return { conv: summarizeConv(cid, c.user.id) };
  });
  R('GET', '/api/spaces/public', (c) => {
    const q = '%' + U.escapeLike(str(c.query.q, 60)) + '%';
    const rows = P(`SELECT c.id,c.name,c.description,c.avatar_file,(SELECT COUNT(*) FROM members WHERE conv_id=c.id) AS member_count
      FROM conversations c WHERE c.type='group' AND c.is_public=1 AND c.name LIKE ? ESCAPE '\\'
      AND c.id NOT IN (SELECT conv_id FROM members WHERE user_id=?) ORDER BY member_count DESC LIMIT 30`).all(q, c.user.id);
    return { spaces: rows };
  });

  // ---------- messages ----------
  R('GET', '/api/conversations/:id/messages', (c) => {
    const cid = int(c.params.id); requireMember(cid, c.user.id);
    const limit = Math.min(Math.max(int(c.query.limit) || 40, 1), 100);
    const before = int(c.query.before), after = int(c.query.after), around = int(c.query.around), thread = int(c.query.thread);
    let rows, hasMoreBefore = false, hasMoreAfter = false;
    if (thread) {
      const root = P('SELECT id FROM messages WHERE id=? AND conv_id=? AND thread_root IS NULL').get(thread, cid);
      if (!root) throw new HttpError(404, 'not_found');
      rows = P(MSG_SQL + ' WHERE m.conv_id=? AND (m.id=? OR m.thread_root=?) ORDER BY m.id ASC LIMIT 500').all(cid, thread, thread);
    } else if (after) {
      rows = P(MSG_SQL + ' WHERE m.conv_id=? AND m.id>? ORDER BY m.id ASC LIMIT ?').all(cid, after, limit + 1);
      if (rows.length > limit) { hasMoreAfter = true; rows.pop(); }
    } else if (around) {
      const a = P(MSG_SQL + ' WHERE m.conv_id=? AND m.thread_root IS NULL AND m.id<=? ORDER BY m.id DESC LIMIT 26').all(cid, around);
      if (a.length > 25) { hasMoreBefore = true; a.pop(); }
      const z = P(MSG_SQL + ' WHERE m.conv_id=? AND m.thread_root IS NULL AND m.id>? ORDER BY m.id ASC LIMIT 26').all(cid, around);
      if (z.length > 25) { hasMoreAfter = true; z.pop(); }
      rows = [...a.reverse(), ...z];
    } else {
      rows = before
        ? P(MSG_SQL + ' WHERE m.conv_id=? AND m.thread_root IS NULL AND m.id<? ORDER BY m.id DESC LIMIT ?').all(cid, before, limit + 1)
        : P(MSG_SQL + ' WHERE m.conv_id=? AND m.thread_root IS NULL ORDER BY m.id DESC LIMIT ?').all(cid, limit + 1);
      if (rows.length > limit) { hasMoreBefore = true; rows.pop(); }
      rows.reverse();
    }
    return { messages: rows.map(shapeMsg), has_more_before: hasMoreBefore, has_more_after: hasMoreAfter };
  });

  R('GET', '/api/conversations/:id/pins', (c) => {
    const cid = int(c.params.id); requireMember(cid, c.user.id);
    return { messages: P(MSG_SQL + ' WHERE m.conv_id=? AND m.pinned=1 AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 30').all(cid).map(shapeMsg) };
  });
  R('GET', '/api/conversations/:id/media', (c) => { // shared files & links
    const cid = int(c.params.id); requireMember(cid, c.user.id);
    const files = P(MSG_SQL + " WHERE m.conv_id=? AND m.file_id IS NOT NULL AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 60").all(cid).map(shapeMsg);
    const linkRows = P(MSG_SQL + " WHERE m.conv_id=? AND m.kind IN ('text','meeting') AND m.deleted_at IS NULL AND (m.body LIKE '%http://%' OR m.body LIKE '%https://%') ORDER BY m.id DESC LIMIT 60").all(cid).map(shapeMsg);
    return { files, links: linkRows };
  });

  function postMessage(c, cid, { kind, body, reply_to, thread_root, file_id }) {
    const m = requireMember(cid, c.user.id); const conv = getConv(cid);
    const reason = sendBlockReason(conv, c.user.id, m);
    if (reason) throw new HttpError(403, reason);
    if (kind === 'text' || kind === 'file') guardText(c.user, body, 'message');
    if (!limiter.hit('send:' + c.user.id, 60, 60e3)) throw new HttpError(429, 'rate_limited');
    if (reply_to) {
      const r = P('SELECT id FROM messages WHERE id=? AND conv_id=? AND deleted_at IS NULL AND kind!=\'system\'').get(reply_to, cid);
      if (!r) throw new HttpError(400, 'invalid_reply');
    } else reply_to = null;
    if (thread_root) {
      if (conv.type !== 'group') throw new HttpError(400, 'no_threads');
      const r = P("SELECT id FROM messages WHERE id=? AND conv_id=? AND thread_root IS NULL AND kind!='system' AND deleted_at IS NULL").get(thread_root, cid);
      if (!r) throw new HttpError(400, 'invalid_thread');
    } else thread_root = null;
    if (file_id) {
      const f = P("SELECT * FROM files WHERE id=? AND uploader=? AND conv_id=? AND purpose='attachment' AND attached=0").get(file_id, c.user.id, cid);
      if (!f) throw new HttpError(400, 'invalid_file');
      kind = 'file';
    } else file_id = null;
    if (kind === 'text' && !body) throw new HttpError(400, 'empty_message');
    const res = tx(() => {
      const r = P('INSERT INTO messages(conv_id,sender_id,kind,body,reply_to,thread_root,file_id,created_at) VALUES(?,?,?,?,?,?,?,?)').run(cid, c.user.id, kind, body, reply_to, thread_root, file_id, Date.now());
      if (file_id) P('UPDATE files SET attached=1 WHERE id=?').run(file_id);
      P('UPDATE members SET last_read_id=? WHERE conv_id=? AND user_id=?').run(r.lastInsertRowid, cid, c.user.id);
      P('UPDATE members SET archived=0 WHERE conv_id=? AND user_id!=?').run(cid, c.user.id);
      return r;
    });
    const msg = loadMsg(res.lastInsertRowid);
    const ids = rt.memberIds(cid);
    rt.toUsers(ids, { t: 'message.new', msg, client_id: c.body.client_id ? String(c.body.client_id).slice(0, 40) : undefined });
    // delivery receipts (DM): recipient has a live socket right now
    if (conv.type === 'dm') for (const uid of ids) if (uid !== c.user.id && rt.isOnline(uid)) {
      P('UPDATE members SET delivered_id=MAX(delivered_id,?) WHERE conv_id=? AND user_id=?').run(msg.id, cid, uid);
      rt.toConv(cid, { t: 'delivered', conv: cid, user_id: uid, up_to: msg.id });
    }
    rt.toUser(c.user.id, { t: 'self.read', conv: cid, up_to: msg.id });
    pushConv(cid, ids);
    return msg;
  }
  R('POST', '/api/conversations/:id/messages', (c) => {
    const cid = int(c.params.id); const b = c.body;
    let kind = 'text', body = typeof b.body === 'string' ? b.body.replace(/\r\n/g, '\n').trim().slice(0, 4000) : '';
    if (b.kind === 'sticker') { if (!STICKERS.includes(b.body)) throw new HttpError(400, 'invalid_sticker'); kind = 'sticker'; body = b.body; }
    return { message: postMessage(c, cid, { kind, body, reply_to: int(b.reply_to), thread_root: int(b.thread_root), file_id: int(b.file_id) }) };
  });
  R('POST', '/api/conversations/:id/meeting', (c) => {
    if (!config.meetingBase) throw new HttpError(501, 'meetings_not_configured');
    const cid = int(c.params.id);
    const url = `${config.meetingBase.replace(/\/+$/, '')}/FriendSpace-${U.randomToken(8)}`;
    return { message: postMessage(c, cid, { kind: 'meeting', body: url, reply_to: null, thread_root: null, file_id: null }) };
  });

  function getEditable(c) {
    const id = int(c.params.id);
    const r = id && P('SELECT * FROM messages WHERE id=?').get(id);
    if (!r) throw new HttpError(404, 'not_found');
    const m = requireMember(r.conv_id, c.user.id);
    return { r, m, conv: getConv(r.conv_id) };
  }
  R('PATCH', '/api/messages/:id', (c) => {
    const { r } = getEditable(c);
    if (r.sender_id !== c.user.id || r.kind !== 'text' || r.deleted_at) throw new HttpError(403, 'forbidden');
    const body = typeof c.body.body === 'string' ? c.body.body.trim().slice(0, 4000) : '';
    if (!body) throw new HttpError(400, 'empty_message');
    if (body !== r.body) guardText(c.user, body, 'message_edit');
    if (body !== r.body) P('UPDATE messages SET body=?, edited_at=? WHERE id=?').run(body, Date.now(), r.id);
    const msg = loadMsg(r.id);
    rt.toConv(r.conv_id, { t: 'message.update', msg }); pushConv(r.conv_id);
    return { message: msg };
  });
  function deleteMessage(r) {
    P("UPDATE messages SET deleted_at=?, body='', pinned=0, file_id=NULL WHERE id=?").run(Date.now(), r.id);
    if (r.file_id) { const f = P('SELECT stored FROM files WHERE id=?').get(r.file_id); P('DELETE FROM files WHERE id=?').run(r.file_id); if (f) fs.unlink(path.join(uploadDir, f.stored), () => {}); }
    const msg = loadMsg(r.id);
    rt.toConv(r.conv_id, { t: 'message.update', msg }); pushConv(r.conv_id);
    return msg;
  }
  R('DELETE', '/api/messages/:id', (c) => {
    const { r, m, conv } = getEditable(c);
    if (r.deleted_at || r.kind === 'system') throw new HttpError(404, 'not_found');
    if (r.sender_id !== c.user.id && !(conv.type === 'group' && isAdminRole(m))) throw new HttpError(403, 'forbidden');
    return { message: deleteMessage(r) };
  });
  R('POST', '/api/messages/:id/pin', (c) => {
    const { r, m, conv } = getEditable(c);
    if (r.deleted_at || r.kind === 'system') throw new HttpError(404, 'not_found');
    if (conv.type === 'group' && !isAdminRole(m)) throw new HttpError(403, 'forbidden');
    const pin = c.body.pinned ? 1 : 0;
    P('UPDATE messages SET pinned=? WHERE id=?').run(pin, r.id);
    const msg = loadMsg(r.id);
    rt.toConv(r.conv_id, { t: 'message.update', msg });
    return { message: msg };
  });
  R('POST', '/api/conversations/:id/read', (c) => {
    const cid = int(c.params.id); const m = requireMember(cid, c.user.id);
    const mx = P('SELECT MAX(id) mx FROM messages WHERE conv_id=?').get(cid).mx || 0;
    const up = Math.min(int(c.body.up_to) || mx, mx);
    if (up > m.last_read_id) {
      P('UPDATE members SET last_read_id=? WHERE conv_id=? AND user_id=?').run(up, cid, c.user.id);
      const conv = getConv(cid);
      if (conv.type === 'dm') rt.toConv(cid, { t: 'read', conv: cid, user_id: c.user.id, up_to: up }, c.user.id);
      rt.toUser(c.user.id, { t: 'self.read', conv: cid, up_to: up });
    }
    return { ok: true };
  });

  // ---------- search ----------
  R('GET', '/api/search', (c) => {
    if (!limiter.hit('search:' + c.user.id, 90, 60e3)) throw new HttpError(429, 'rate_limited');
    const q = str(c.query.q, 100); const scope = c.query.scope || 'all';
    const out = { people: [], spaces: [], messages: [] };
    if (q.length < 2 && !(scope === 'messages' && (c.query.conv || c.query.from || c.query.to || c.query.kind))) return out;
    const like = '%' + U.escapeLike(q) + '%';
    if (scope === 'all' || scope === 'people') {
      const rows = P(`SELECT * FROM users WHERE deleted=0 AND disabled=0 AND id!=? AND (username LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\')
        AND id NOT IN (SELECT blocker FROM blocks WHERE blocked=?) AND id NOT IN (SELECT blocked FROM blocks WHERE blocker=?) ORDER BY username LIMIT 15`).all(c.user.id, like, like, c.user.id, c.user.id);
      out.people = rows.map((u) => { const f = friendship(c.user.id, u.id); return { ...pub(u), relation: !f ? 'none' : f.status === 'accepted' ? 'friend' : f.requested_by === c.user.id ? 'outgoing' : 'incoming', relation_id: f?.id || null }; });
    }
    if (scope === 'all' || scope === 'people') { // spaces: my groups + public groups
      out.spaces = P(`SELECT c.id,c.name,c.description,c.avatar_file,c.is_public,
          EXISTS(SELECT 1 FROM members WHERE conv_id=c.id AND user_id=?) AS joined
        FROM conversations c WHERE c.type='group' AND c.name LIKE ? ESCAPE '\\'
        AND (c.is_public=1 OR EXISTS(SELECT 1 FROM members WHERE conv_id=c.id AND user_id=?)) LIMIT 15`).all(c.user.id, like, c.user.id).map((r) => ({ ...r, joined: !!r.joined }));
    }
    if (scope === 'all' || scope === 'messages') {
      const where = ["m.conv_id IN (SELECT conv_id FROM members WHERE user_id=?)", 'm.deleted_at IS NULL', "m.kind!='system'"]; const args = [c.user.id];
      if (q) { where.push("(m.body LIKE ? ESCAPE '\\' OR f.name LIKE ? ESCAPE '\\')"); args.push(like, like); }
      const conv = int(c.query.conv); if (conv) { where.push('m.conv_id=?'); args.push(conv); }
      const from = int(c.query.from); if (from) { where.push('m.created_at>=?'); args.push(from); }
      const to = int(c.query.to); if (to) { where.push('m.created_at<?'); args.push(to); }
      const kind = c.query.kind;
      if (kind === 'file') where.push('m.file_id IS NOT NULL');
      else if (kind === 'image') where.push("f.mime LIKE 'image/%'");
      else if (kind === 'link') where.push("(m.body LIKE '%http://%' OR m.body LIKE '%https://%')");
      else if (kind === 'text') where.push("m.kind='text'");
      const rows = P(MSG_SQL + ' WHERE ' + where.join(' AND ') + ' ORDER BY m.id DESC LIMIT 40').all(...args);
      out.messages = rows.map((r) => {
        const s = shapeMsg(r); const cv = getConv(r.conv_id);
        s.conv = { id: cv.id, type: cv.type, name: cv.type === 'dm' ? (peerOf(cv.id, c.user.id)?.display_name || '') : cv.name };
        return s;
      });
    }
    return out;
  });

  // ---------- files ----------
  R('POST', '/api/upload', async (c) => {
    if (!limiter.hit('upload:' + c.user.id, 40, 60e3)) throw new HttpError(429, 'rate_limited');
    const purpose = c.query.purpose === 'avatar' ? 'avatar' : 'attachment';
    const name = cleanName(c.query.name);
    const ext = (name.split('.').pop() || '').toLowerCase();
    const def = EXT[ext];
    if (purpose === 'attachment') guardText(c.user, name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' '), 'file_name');
    if (!def || (purpose === 'avatar' && def[1] !== 'img')) throw new HttpError(415, 'file_type_not_allowed');
    let cid = null;
    if (purpose === 'attachment') {
      cid = int(c.query.conv); const m = requireMember(cid, c.user.id); const conv = getConv(cid);
      const reason = sendBlockReason(conv, c.user.id, m); if (reason) throw new HttpError(403, reason);
    }
    const max = purpose === 'avatar' ? config.maxAvatar : config.maxUpload;
    if (Number(c.req.headers['content-length']) > max) throw new HttpError(413, 'too_large');
    const buf = await U.readBody(c.req, max);
    if (!buf.length) throw new HttpError(400, 'empty_file');
    if (!magicOk(def[1], ext, buf)) throw new HttpError(415, 'file_type_mismatch');
    const stored = U.randomToken(16);
    fs.writeFileSync(path.join(uploadDir, stored), buf, { mode: 0o600 });
    const r = P('INSERT INTO files(uploader,conv_id,purpose,name,mime,size,stored,created_at) VALUES(?,?,?,?,?,?,?,?)').run(c.user.id, cid, purpose, name, def[0].split(';')[0], buf.length, stored, Date.now());
    return { file: { id: r.lastInsertRowid, name, mime: def[0].split(';')[0], size: buf.length } };
  });

  R('GET', '/api/files/:id', { raw: true }, (c) => {
    const f = P('SELECT * FROM files WHERE id=?').get(int(c.params.id));
    if (!f) throw new HttpError(404, 'not_found');
    if (f.purpose === 'attachment' && !getMember(f.conv_id, c.user.id)) throw new HttpError(404, 'not_found');
    const file = path.join(uploadDir, f.stored);
    if (!fs.existsSync(file)) throw new HttpError(404, 'not_found');
    const ext = f.name.split('.').pop().toLowerCase();
    const mime = (EXT[ext] || ['application/octet-stream'])[0];
    const inline = mime.startsWith('image/') || (mime === 'application/pdf' && c.query.inline === '1');
    const h = {
      'Content-Type': mime, 'Content-Length': f.size, 'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox", 'Cache-Control': 'private, max-age=86400',
      'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(f.name)}`,
    };
    c.res.writeHead(200, h); fs.createReadStream(file).pipe(c.res);
    return undefined;
  });

  setInterval(cleanupOrphans, 3600e3).unref();
  function cleanupOrphans() {
    const old = P('SELECT id,stored FROM files WHERE attached=0 AND created_at<?').all(Date.now() - 3600e3);
    for (const f of old) { P('DELETE FROM files WHERE id=?').run(f.id); fs.unlink(path.join(uploadDir, f.stored), () => {}); }
    P('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
    return old.length;
  }
  cleanupOrphans();

  // ---------- reports ----------
  R('POST', '/api/reports', (c) => {
    if (!limiter.hit('report:' + c.user.id, 20, 3600e3)) throw new HttpError(429, 'rate_limited');
    const type = c.body.type === 'message' ? 'message' : c.body.type === 'user' ? 'user' : null; const id = int(c.body.id);
    const reason = str(c.body.reason, 500);
    if (!type || !id || !reason) throw new HttpError(400, 'invalid');
    let snap = {};
    if (type === 'message') {
      const r = P(MSG_SQL + ' WHERE m.id=?').get(id);
      if (!r || !getMember(r.conv_id, c.user.id) || r.deleted_at) throw new HttpError(404, 'not_found');
      snap = { body: r.body, sender_id: r.sender_id, conv_id: r.conv_id, kind: r.kind, file: r.fname || null };
      if (r.sender_id === c.user.id) throw new HttpError(400, 'self_report');
    } else {
      const u = getUser(id); if (!u || u.id === c.user.id) throw new HttpError(404, 'not_found');
      snap = { username: u.username, display_name: u.display_name };
    }
    if (P("SELECT 1 FROM reports WHERE reporter=? AND target_type=? AND target_id=? AND status='open'").get(c.user.id, type, id)) return { ok: true };
    P('INSERT INTO reports(reporter,target_type,target_id,reason,snapshot,created_at) VALUES(?,?,?,?,?,?)').run(c.user.id, type, id, reason, JSON.stringify(snap), Date.now());
    return { ok: true };
  });

  // ---------- admin ----------
  const staff = (c) => needRole(c, 'admin', 'moderator');
  R('GET', '/api/admin/stats', (c) => {
    staff(c);
    const n = (sql) => P(sql).get().n;
    return { users: n("SELECT COUNT(*) n FROM users WHERE deleted=0"), disabled: n('SELECT COUNT(*) n FROM users WHERE disabled=1 AND deleted=0'), online: rt.onlineIds().length,
      groups: n("SELECT COUNT(*) n FROM conversations WHERE type='group'"), messages: n("SELECT COUNT(*) n FROM messages WHERE kind!='system'"), open_reports: n("SELECT COUNT(*) n FROM reports WHERE status='open'"), open_appeals: n("SELECT COUNT(*) n FROM appeals WHERE status='open'"), suspended: P('SELECT COUNT(*) n FROM users WHERE suspended_until>?').get(Date.now()).n };
  });
  R('GET', '/api/admin/users', (c) => {
    staff(c);
    const q = '%' + U.escapeLike(str(c.query.q, 60)) + '%';
    const rows = P(`SELECT * FROM users WHERE deleted=0 AND (username LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\') ORDER BY id DESC LIMIT 100`).all(q, q, q);
    return { users: rows.map((u) => ({ ...pub(u), email: c.user.role === 'admin' ? u.email : undefined, role: u.role, disabled: !!u.disabled, created_at: u.created_at, last_seen: u.last_seen, online: rt.isOnline(u.id), suspended_until: isSuspended(u) ? u.suspended_until : null })) };
  });
  function guardTarget(c, t) {
    if (!t || t.deleted) throw new HttpError(404, 'not_found');
    if (t.id === c.user.id) throw new HttpError(400, 'self_action');
    if (c.user.role !== 'admin' && t.role !== 'user') throw new HttpError(403, 'forbidden');
  }
  R('PATCH', '/api/admin/users/:id', (c) => {
    staff(c); const t = getUser(int(c.params.id)); guardTarget(c, t);
    if (c.body.disabled !== undefined) {
      const d = c.body.disabled ? 1 : 0;
      P('UPDATE users SET disabled=? WHERE id=?').run(d, t.id);
      if (d) { P('DELETE FROM sessions WHERE user_id=?').run(t.id); rt.kickUser(t.id); }
      audit(c.user.id, d ? 'user.disable' : 'user.enable', t.username, str(c.body.reason, 200));
    }
    if (c.body.role !== undefined) {
      needRole(c, 'admin');
      if (!['user', 'moderator', 'admin'].includes(c.body.role)) throw new HttpError(400, 'invalid');
      P('UPDATE users SET role=? WHERE id=?').run(c.body.role, t.id);
      audit(c.user.id, 'user.role', t.username, c.body.role);
    }
    return { ok: true };
  });
  R('DELETE', '/api/admin/users/:id', (c) => {
    needRole(c, 'admin'); const t = getUser(int(c.params.id)); guardTarget(c, t);
    // Soft delete: personal data removed, messages kept (shown as a deleted user) so group history stays intact.
    tx(() => {
      P("UPDATE users SET deleted=1, disabled=1, email=?, username=?, display_name='—', status_text='', avatar_file=NULL, password_hash='' WHERE id=?").run(`deleted-${t.id}@invalid`, `deleted_${t.id}`, t.id);
      P('DELETE FROM sessions WHERE user_id=?').run(t.id);
      P('DELETE FROM friendships WHERE user_a=? OR user_b=?').run(t.id, t.id);
      P('DELETE FROM blocks WHERE blocker=? OR blocked=?').run(t.id, t.id);
    });
    rt.kickUser(t.id);
    audit(c.user.id, 'user.delete', t.username, null);
    for (const p of rt.peersOf(t.id)) { pushFriends(p); }
    return { ok: true };
  });
  R('POST', '/api/admin/users/:id/reset-link', (c) => { // lets an admin hand a reset link over when email is not configured
    needRole(c, 'admin'); const t = getUser(int(c.params.id)); guardTarget(c, t);
    const token = U.randomToken(32);
    P('INSERT INTO reset_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)').run(U.sha256(token), t.id, Date.now() + 3600e3);
    audit(c.user.id, 'user.reset_link', t.username, null);
    return { link: `${config.publicUrl}/?reset=${token}` };
  });
  R('GET', '/api/admin/violations', (c) => {
    staff(c);
    const rows = P(`SELECT v.*, u.username, u.display_name, a.id appeal_id, a.status appeal_status FROM violations v JOIN users u ON u.id=v.user_id
      LEFT JOIN appeals a ON a.violation_id=v.id ORDER BY v.id DESC LIMIT 100`).all();
    return { violations: rows };
  });
  R('GET', '/api/admin/appeals', (c) => {
    staff(c);
    const status = ['open', 'accepted', 'rejected'].includes(c.query.status) ? c.query.status : 'open';
    const rows = P(`SELECT a.*, u.username, u.display_name, v.context, v.category, v.term, v.text vtext, v.created_at vat, v.suspended_until, v.status vstatus
      FROM appeals a JOIN users u ON u.id=a.user_id JOIN violations v ON v.id=a.violation_id WHERE a.status=? ORDER BY a.id DESC LIMIT 100`).all(status);
    return { appeals: rows };
  });
  function liftSuspension(uid, status, by) {
    const u = getUser(uid);
    P('UPDATE users SET suspended_until=NULL, suspension_at=NULL, suspension_violation=NULL WHERE id=?').run(uid);
    if (u.suspension_violation) P('UPDATE violations SET status=?, reviewed_by=?, reviewed_at=? WHERE id=?').run(status, by, Date.now(), u.suspension_violation);
  }
  R('PATCH', '/api/admin/appeals/:id', (c) => {
    staff(c);
    const a = P("SELECT * FROM appeals WHERE id=? AND status='open'").get(int(c.params.id)); if (!a) throw new HttpError(404, 'not_found');
    const accept = c.body.decision === 'accept'; const response = str(c.body.response, 500);
    const u = getUser(a.user_id);
    tx(() => {
      P('UPDATE appeals SET status=?, handled_by=?, handled_at=?, response=? WHERE id=?').run(accept ? 'accepted' : 'rejected', c.user.id, Date.now(), response, a.id);
      if (accept) { if (u.suspension_violation === a.violation_id) liftSuspension(u.id, 'overturned', c.user.id); else P("UPDATE violations SET status='overturned', reviewed_by=?, reviewed_at=? WHERE id=?").run(c.user.id, Date.now(), a.violation_id); }
      else P("UPDATE violations SET status='upheld', reviewed_by=?, reviewed_at=? WHERE id=?").run(c.user.id, Date.now(), a.violation_id);
    });
    audit(c.user.id, accept ? 'appeal.accept' : 'appeal.reject', u.username, response);
    mailer({ to: u.email, subject: accept ? 'FriendSpace — appeal accepted / تم قبول اعتراضك' : 'FriendSpace — appeal decision / قرار الاعتراض', text: (accept ? 'Your appeal was accepted and your account is active again.\nتم قبول اعتراضك وإعادة تفعيل حسابك.' : 'Your appeal was reviewed and the suspension stays until its end date.\nتمت مراجعة اعتراضك وبقي الإيقاف حتى تاريخ انتهائه.') + (response ? '\n\n' + response : '') }).catch(() => {});
    return { ok: true };
  });
  R('POST', '/api/admin/users/:id/lift-suspension', (c) => {
    staff(c); const t = getUser(int(c.params.id)); guardTarget(c, t);
    if (!isSuspended(t)) throw new HttpError(400, 'not_suspended');
    tx(() => { liftSuspension(t.id, 'overturned', c.user.id); P("UPDATE appeals SET status='accepted', handled_by=?, handled_at=?, response=COALESCE(response,'') WHERE violation_id=? AND status='open'").run(c.user.id, Date.now(), t.suspension_violation); });
    audit(c.user.id, 'user.lift_suspension', t.username, null);
    return { ok: true };
  });
  R('GET', '/api/admin/reports', (c) => {
    staff(c);
    const status = ['open', 'resolved', 'dismissed'].includes(c.query.status) ? c.query.status : 'open';
    const rows = P('SELECT r.*, u.username reporter_name FROM reports r JOIN users u ON u.id=r.reporter WHERE r.status=? ORDER BY r.id DESC LIMIT 100').all(status);
    return { reports: rows.map((r) => ({ ...r, snapshot: safeJson(r.snapshot, {}), target_user: r.target_type === 'user' ? pub(getUser(r.target_id)) : pub(getUser(safeJson(r.snapshot, {}).sender_id)) })) };
  });
  R('PATCH', '/api/admin/reports/:id', (c) => {
    staff(c);
    const r = P('SELECT * FROM reports WHERE id=?').get(int(c.params.id)); if (!r) throw new HttpError(404, 'not_found');
    const status = c.body.status === 'dismissed' ? 'dismissed' : 'resolved';
    const action = c.body.action;
    if (action === 'delete_message' && r.target_type === 'message') {
      const m = P('SELECT * FROM messages WHERE id=?').get(r.target_id);
      if (m && !m.deleted_at) { deleteMessage(m); audit(c.user.id, 'message.delete', r.target_id, 'report #' + r.id); }
    } else if (action === 'disable_user') {
      const uid = r.target_type === 'user' ? r.target_id : safeJson(r.snapshot, {}).sender_id;
      const t = getUser(uid); guardTarget(c, t);
      P('UPDATE users SET disabled=1 WHERE id=?').run(t.id); P('DELETE FROM sessions WHERE user_id=?').run(t.id); rt.kickUser(t.id);
      audit(c.user.id, 'user.disable', t.username, 'report #' + r.id);
    }
    P('UPDATE reports SET status=?, handled_by=?, handled_at=?, note=? WHERE id=?').run(status, c.user.id, Date.now(), str(c.body.note, 300), r.id);
    audit(c.user.id, 'report.' + status, r.id, action || '');
    return { ok: true };
  });
  R('GET', '/api/admin/spaces', (c) => {
    staff(c);
    return { spaces: P(`SELECT c.id,c.name,c.description,c.created_at,(SELECT COUNT(*) FROM members WHERE conv_id=c.id) member_count,
      (SELECT display_name FROM users WHERE id=c.created_by) owner FROM conversations c WHERE c.type='group' AND c.is_public=1 ORDER BY c.id DESC LIMIT 100`).all() };
  });
  R('DELETE', '/api/admin/spaces/:id', (c) => {
    needRole(c, 'admin'); const conv = getConv(int(c.params.id));
    if (!conv || conv.type !== 'group' || !conv.is_public) throw new HttpError(404, 'not_found');
    deleteConversation(conv.id); audit(c.user.id, 'space.delete', conv.name, null);
    return { ok: true };
  });
  R('GET', '/api/admin/audit', (c) => {
    needRole(c, 'admin');
    return { audit: P('SELECT a.*, u.username actor_name FROM audit a LEFT JOIN users u ON u.id=a.actor ORDER BY a.id DESC LIMIT 100').all() };
  });

  // --- admin-only tools: settings, site-wide announcements, data export ---
  R('GET', '/api/admin/settings', (c) => { needRole(c, 'admin'); return { moderation: config.moderation, registration_open: config.registrationOpen, suspend_days: config.suspendDays }; });
  R('PATCH', '/api/admin/settings', (c) => {
    needRole(c, 'admin'); const b = c.body;
    if (b.moderation !== undefined) { if (!['suspend', 'off'].includes(b.moderation)) throw new HttpError(400, 'invalid'); config.moderation = b.moderation; saveSetting('moderation', b.moderation); }
    if (b.registration_open !== undefined) { config.registrationOpen = !!b.registration_open; saveSetting('registration_open', config.registrationOpen ? 1 : 0); }
    if (b.suspend_days !== undefined) { const d = int(b.suspend_days); if (!(d >= 1 && d <= 90)) throw new HttpError(400, 'invalid'); config.suspendDays = d; saveSetting('suspend_days', d); }
    audit(c.user.id, 'settings.update', null, JSON.stringify(b).slice(0, 200));
    return { moderation: config.moderation, registration_open: config.registrationOpen, suspend_days: config.suspendDays };
  });
  const liveAnnouncements = () => P('SELECT id, body, created_at, expires_at FROM announcements WHERE expires_at>? ORDER BY id DESC LIMIT 5').all(Date.now());
  R('GET', '/api/announcements', () => ({ announcements: liveAnnouncements() }));
  R('GET', '/api/admin/announcements', (c) => { needRole(c, 'admin'); return { announcements: P('SELECT * FROM announcements ORDER BY id DESC LIMIT 30').all() }; });
  R('POST', '/api/admin/announcements', (c) => {
    needRole(c, 'admin');
    const body = str(c.body.body, 500); if (body.length < 2) throw new HttpError(400, 'invalid');
    const days = Math.min(30, Math.max(1, int(c.body.days) || 3));
    const now = Date.now();
    const id = Number(P('INSERT INTO announcements(author,body,created_at,expires_at) VALUES(?,?,?,?)').run(c.user.id, body, now, now + days * 864e5).lastInsertRowid);
    audit(c.user.id, 'announcement.create', '#' + id, body.slice(0, 80));
    const a = { id, body, created_at: now, expires_at: now + days * 864e5 };
    rt.toUsers(rt.onlineIds(), { t: 'announce', announcement: a });
    return { announcement: a };
  });
  R('DELETE', '/api/admin/announcements/:id', (c) => { needRole(c, 'admin'); P('UPDATE announcements SET expires_at=0 WHERE id=?').run(int(c.params.id)); audit(c.user.id, 'announcement.remove', '#' + c.params.id, null); return { ok: true }; });
  R('GET', '/api/admin/export', (c) => { // account + moderation data only: private messages are never exported
    needRole(c, 'admin');
    audit(c.user.id, 'data.export', null, null);
    const users = P('SELECT id,username,display_name,email,role,disabled,deleted,suspended_until,created_at,last_seen FROM users').all();
    c.res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="friendspace-export.json"', 'Cache-Control': 'no-store' });
    c.res.end(JSON.stringify({ exported_at: new Date().toISOString(), users, violations: P('SELECT * FROM violations').all(), appeals: P('SELECT * FROM appeals').all(), audit: P('SELECT * FROM audit ORDER BY id DESC LIMIT 1000').all() }, null, 1));
  });

  // ---------- dispatcher ----------
  function originOk(req) {
    const o = req.headers.origin;
    if (!o) return true;
    try { const u = new URL(o); return u.host === req.headers.host || config.allowedOrigins.includes(o); } catch { return false; }
  }
  async function handle(req, res, url) {
    const route = routes.find((r) => r.method === req.method && r.re.test(url.pathname));
    if (!route) throw new HttpError(404, 'not_found');
    const m = route.re.exec(url.pathname);
    const params = {}; route.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
    const c = { req, res, params, query: Object.fromEntries(url.searchParams), ip: ip(req), body: {} };
    if (req.method !== 'GET') {
      if (!originOk(req) || req.headers['x-requested-with'] !== 'FriendSpace') throw new HttpError(403, 'csrf');
    }
    if (route.opts.auth !== false) {
      const a = authenticate(req);
      if (!a) throw new HttpError(401, 'unauthorized');
      c.user = a.user; c.sessionId = a.sessionId;
      if (a.suspended && !route.opts.allowSuspended) throw new HttpError(403, 'account_suspended', { suspended_until: a.user.suspended_until });
    }
    if (!limiter.hit('api:' + c.ip, 600, 60e3)) throw new HttpError(429, 'rate_limited');
    const isUpload = url.pathname === '/api/upload';
    if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method) && !isUpload) c.body = await U.readJson(req);
    const out = await route.fn(c);
    if (res.headersSent || out === undefined) return;
    const body = JSON.stringify(out);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  }

  return { handle, authenticate, originOk, limiter, cleanupOrphans };
};
module.exports.STICKERS = STICKERS;
