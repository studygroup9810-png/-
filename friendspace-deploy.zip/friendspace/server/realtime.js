'use strict';
// Real-time hub: tracks live sockets per user, presence, delivery receipts, typing.
module.exports = function createRealtime(db) {
  const clients = new Map(); // userId -> Set<Conn>
  const cache = new Map();
  const P = (sql) => { let s = cache.get(sql); if (!s) { s = db.prepare(sql); cache.set(sql, s); } return s; };

  const isOnline = (uid) => clients.has(uid);
  const onlineIds = () => [...clients.keys()];

  function toUser(uid, obj) {
    const set = clients.get(uid);
    if (!set) return;
    const s = JSON.stringify(obj);
    for (const c of set) c.send(s);
  }
  function toUsers(ids, obj, except) {
    const s = JSON.stringify(obj);
    for (const uid of new Set(ids)) {
      if (uid === except) continue;
      const set = clients.get(uid);
      if (set) for (const c of set) c.send(s);
    }
  }
  const memberIds = (convId) => P('SELECT user_id FROM members WHERE conv_id=?').all(convId).map((r) => r.user_id);
  const toConv = (convId, obj, except) => toUsers(memberIds(convId), obj, except);

  function peersOf(uid) {
    const a = P(`SELECT DISTINCT m2.user_id AS id FROM members m1 JOIN members m2 ON m1.conv_id=m2.conv_id
                 WHERE m1.user_id=? AND m2.user_id!=?`).all(uid, uid).map((r) => r.id);
    const f = P(`SELECT CASE WHEN user_a=? THEN user_b ELSE user_a END AS id FROM friendships
                 WHERE status='accepted' AND (user_a=? OR user_b=?)`).all(uid, uid, uid).map((r) => r.id);
    return [...new Set([...a, ...f])];
  }

  function broadcastPresence(uid, online) {
    const last_seen = Date.now();
    toUsers(peersOf(uid), { t: 'presence', user_id: uid, online, last_seen });
  }

  function markDelivered(uid) {
    const rows = P(`SELECT m.conv_id, m.delivered_id,
        (SELECT MAX(id) FROM messages WHERE conv_id=m.conv_id) AS mx
      FROM members m JOIN conversations c ON c.id=m.conv_id
      WHERE m.user_id=? AND c.type='dm'`).all(uid);
    for (const r of rows) {
      if (r.mx && r.mx > r.delivered_id) {
        P('UPDATE members SET delivered_id=? WHERE conv_id=? AND user_id=?').run(r.mx, r.conv_id, uid);
        toConv(r.conv_id, { t: 'delivered', conv: r.conv_id, user_id: uid, up_to: r.mx }, uid);
      }
    }
  }

  function attach(conn, user, sessionId) {
    conn.userId = user.id; conn.sessionId = sessionId; conn.alive = true; conn.lastTyping = 0;
    let set = clients.get(user.id);
    const first = !set;
    if (!set) { set = new Set(); clients.set(user.id, set); }
    set.add(conn);
    conn.send(JSON.stringify({ t: 'hello', user_id: user.id }));
    if (first) broadcastPresence(user.id, true);
    markDelivered(user.id);

    conn.on('message', (text) => {
      let m; try { m = JSON.parse(text); } catch { return; }
      if (!m || typeof m !== 'object') return;
      if (m.t === 'ping') { conn.send('{"t":"pong"}'); return; }
      if (m.t === 'typing') {
        const t = Date.now();
        if (t - conn.lastTyping < 1500) return;
        conn.lastTyping = t;
        const convId = Number(m.conv);
        if (!Number.isSafeInteger(convId)) return;
        const mem = P('SELECT 1 FROM members WHERE conv_id=? AND user_id=?').get(convId, user.id);
        if (!mem) return;
        toConv(convId, { t: 'typing', conv: convId, user_id: user.id, name: user.display_name }, user.id);
      }
    });
    conn.on('close', () => {
      const s = clients.get(user.id);
      if (s) { s.delete(conn); if (!s.size) clients.delete(user.id); }
      if (!clients.has(user.id)) {
        try { P('UPDATE users SET last_seen=? WHERE id=?').run(Date.now(), user.id); } catch {}
        try { broadcastPresence(user.id, false); } catch {}
      }
    });
  }

  function kickUser(uid, code = 4001) { const s = clients.get(uid); if (s) for (const c of [...s]) c.close(code); }
  function kickSession(sid, code = 4001) {
    for (const s of clients.values()) for (const c of [...s]) if (c.sessionId === sid) c.close(code);
  }
  function kickUserExceptSession(uid, sid) {
    const s = clients.get(uid); if (s) for (const c of [...s]) if (c.sessionId !== sid) c.close(4001);
  }

  const hb = setInterval(() => {
    for (const s of clients.values()) for (const c of [...s]) {
      if (!c.alive) { c.terminate(); continue; }
      c.alive = false; c.ping();
    }
  }, 25000);
  hb.unref();

  return { attach, toUser, toUsers, toConv, memberIds, isOnline, onlineIds, peersOf, kickUser, kickSession, kickUserExceptSession, markDelivered, stop() { clearInterval(hb); for (const set of clients.values()) for (const c of [...set]) c.terminate(); clients.clear(); } };
};
