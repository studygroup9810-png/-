'use strict';
// Rule-based abuse detector (Arabic + English). Word-level matching (no substring matching) to avoid
// "Scunthorpe"-style false positives. Extend with data/moderation-extra.txt ("category:word" per line).
const fs = require('node:fs');

// Categories: profanity | insult | harassment (threats, bullying phrases)
// `d: true` = only counts when directly addressed to someone ("you ...", "يا ...", "انت ...").
const BASE = {
  profanity: [
    // English
    'fuck', 'fucks', 'fucked', 'fucker', 'fuckers', 'fucking', 'motherfucker', 'motherfuckers', 'fuckoff', 'fuckin', 'fuk', 'fck', 'fcuk', 'shit', 'shits', 'shitty', 'bullshit', 'bitch', 'bitches', 'asshole', 'assholes',
    'bastard', 'bastards', 'cunt', 'cunts', 'whore', 'whores', 'slut', 'sluts', 'wanker', 'twat', 'dickhead', 'pussy', 'cocksucker', 'nigger', 'nigga', 'faggot', 'faggots', 'retard', 'retarded',
    // Arabic (normalised spelling: ا for أإآ, ي for ى, ه for ة)
    'شرموطه', 'شرموط', 'شرمطه', 'شراميط', 'عرص', 'معرص', 'منيوك', 'منيوكه', 'متناك', 'متناكه', 'خول', 'خولات', 'كسمك', 'كسمه', 'كسختك', 'كساختك', 'كسامك', 'كسك', 'قحبه', 'قحاب', 'عاهره', 'عاهرات', 'لوطي', 'ابن المتناكه',
    'ابن الكلب', 'ابن الكلاب', 'بنت الكلب', 'ابن الوسخه', 'ابن الزانيه', 'ابن الحرام', 'ابن الشرموطه', 'يلعن ابوك', 'يلعن امك', 'يلعن دينك', 'يلعن ابوكم', 'كس امك', 'كس امه', 'كس اختك', 'نيك امك', 'ينيك', 'زبي', 'طيزك', 'طيزي',
  ],
  insult: [
    { w: 'idiot', d: 1 }, { w: 'moron', d: 1 }, { w: 'stupid', d: 1 }, { w: 'dumb', d: 1 }, { w: 'loser', d: 1 }, { w: 'ugly', d: 1 }, { w: 'trash', d: 1 }, { w: 'pathetic', d: 1 }, { w: 'worthless', d: 1 }, { w: 'scum', d: 1 }, { w: 'fatso', d: 1 }, { w: 'freak', d: 1 }, { w: 'dumbass', d: 1 }, { w: 'jackass', d: 1 }, { w: 'imbecile', d: 1 },
    { w: 'غبي', d: 1 }, { w: 'غبيه', d: 1 }, { w: 'حمار', d: 1 }, { w: 'حماره', d: 1 }, { w: 'كلب', d: 1 }, { w: 'كلبه', d: 1 }, { w: 'حيوان', d: 1 }, { w: 'حقير', d: 1 }, { w: 'حقيره', d: 1 }, { w: 'واطي', d: 1 }, { w: 'تافه', d: 1 }, { w: 'قذر', d: 1 }, { w: 'قذره', d: 1 }, { w: 'وسخ', d: 1 }, { w: 'وسخه', d: 1 }, { w: 'بقر', d: 1 }, { w: 'خنزير', d: 1 }, { w: 'معاق', d: 1 }, { w: 'فاشل', d: 1 }, { w: 'فاشله', d: 1 }, { w: 'ساقط', d: 1 }, { w: 'سافل', d: 1 }, { w: 'نذل', d: 1 }, { w: 'زباله', d: 1 }, { w: 'بهيمه', d: 1 }, { w: 'اهبل', d: 1 }, { w: 'هبله', d: 1 }, { w: 'قرد', d: 1 }, { w: 'سمين', d: 1 }, { w: 'بشع', d: 1 }, { w: 'بشعه', d: 1 },
  ],
  harassment: [
    'kill yourself', 'kys', 'go kill yourself', 'go die', 'you should die', 'hope you die', 'i will kill you', 'i ll kill you', 'ill kill you', 'i will find you', 'nobody likes you', 'nobody loves you', 'everyone hates you', 'i will hurt you', 'i will beat you up', 'i will rape you', 'rape you',
    'اقتل نفسك', 'روح انتحر', 'انتحر', 'موت يا', 'اتمنى تموت', 'اتمني تموت', 'هقتلك', 'سوف اقتلك', 'راح اقتلك', 'رح اقتلك', 'ساقتلك', 'احسن لك تموت', 'هدبحك', 'هذبحك', 'اذبحك', 'هموتك', 'راح اموتك', 'ما حد بيحبك', 'محد يحبك', 'الكل يكرهك', 'الكل بيكرهك', 'هكسر دماغك', 'هكسر وشك', 'هاغتصبك', 'اغتصبك',
  ],
};
const ADDRESS = new Set(['you', 'u', 'ur', 'your', 'youre', 'ya', 'يا', 'انت', 'انتي', 'انتا', 'انتو', 'انتم', 'يالي', 'ياا', 'يابن']);

const FILLER = new Set(['a', 'an', 'such', 'so', 'really', 'very', 'too', 'just', 'absolutely', 'total', 'totally', 'complete', 'completely', 'big', 'real', 'am', 'are', 'is', 'were', 'was', 'be', 'being', 're', 'cant', 'dont', 'also', 'both', 'كل', 'اصلا', 'فعلا', 'بجد', 'جدا', 'والله', 'انك', 'كده', 'مره', 'اوي', 'قوي', 'كتير', 'شو', 'ما']);
const AR_DIAC = /[ً-ٰٟۖ-ۭـ]/g;
const LEET = { 0: 'o', 1: 'i', 3: 'e', 4: 'a', 5: 's', 7: 't', 8: 'b', '@': 'a', $: 's', '!': 'i', '€': 'e', '¡': 'i' };

function norm(s) {
  return String(s).normalize('NFKC').toLowerCase().replace(AR_DIAC, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ء/g, '')
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x6f0))
    .replace(/[​-‏‪-‮⁠﻿]/g, '').replace(/['’`]/g, '');
}
const collapse = (w) => w.replace(/(.)\1+/gu, '$1');
const isLetter = (ch) => /\p{L}/u.test(ch);

function tokenize(text) {
  let s = norm(text);
  // leet only inside tokens that already contain a letter
  const raw = s.split(/[^\p{L}\p{N}@$!€¡]+/u).filter(Boolean);
  const toks = raw.map((tk) => {
    if (/\p{L}/u.test(tk)) tk = [...tk].map((ch) => LEET[ch] || ch).join('');
    return tk.replace(/[@$!€¡]/g, '');
  }).filter(Boolean);
  // glue runs of single letters: "f u c k" / "f.u.c.k" -> "fuck"
  const out = [];
  for (let i = 0; i < toks.length;) {
    if ([...toks[i]].length === 1 && isLetter(toks[i])) {
      let j = i; let glued = '';
      while (j < toks.length && [...toks[j]].length === 1 && isLetter(toks[j])) { glued += toks[j]; j++; }
      if (j - i >= 3) {
        glued = collapse(glued); out.push(glued);
        // "f u c k y o u": also look for listed words inside the glued run
        for (const w of singles.keys()) if (w.length >= 3 && glued.length > w.length && glued.includes(w) && !singles.get(w).d) out.push(w);
        i = j; continue;
      }
    }
    out.push(toks[i]); i++;
  }
  return out.map(collapse);
}

function variants(tok) { // strip common Arabic attached particles/articles
  const v = new Set([tok]);
  const strip = (x) => {
    if (x.startsWith('ال') && x.length > 4) v.add(x.slice(2));
    if (/^[وفبلك]/.test(x) && x.length > 3) { v.add(x.slice(1)); if (x.slice(1).startsWith('ال') && x.length > 6) v.add(x.slice(3)); }
  };
  strip(tok);
  for (const x of [...v]) { if (x.endsWith('ك') && x.length > 4) v.add(x.slice(0, -1)); if (x.endsWith('كم') && x.length > 5) v.add(x.slice(0, -2)); if (x.endsWith('ه') && x.length > 4) v.add(x.slice(0, -1)); if (x.endsWith('ها') && x.length > 5) v.add(x.slice(0, -2)); }
  return v;
}

let singles = new Map(); // word -> {category, d}
let phrases = []; // {toks:[...], category}
function addEntry(category, entry) {
  const word = typeof entry === 'string' ? entry : entry.w; const d = typeof entry === 'string' ? 0 : entry.d;
  const toks = tokenize(word); if (!toks.length) return;
  if (toks.length === 1) singles.set(toks[0], { category, d: !!d });
  else phrases.push({ toks, category });
}
function build(extra = []) {
  singles = new Map(); phrases = [];
  for (const [cat, list] of Object.entries(BASE)) for (const e of list) addEntry(cat, e);
  for (const [cat, w] of extra) addEntry(cat, w);
  // single-token insults must not duplicate profanity entries
}
build();

function loadExtra(file) {
  const extra = [];
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const l = line.trim(); if (!l || l.startsWith('#')) continue;
      const m = /^(profanity|insult|harassment):(.+)$/.exec(l);
      extra.push(m ? [m[1], m[2].trim()] : ['profanity', l]);
    }
  } catch {}
  build(extra);
  return extra.length;
}

/** @returns {null | {category:string, term:string}} */
function check(text) {
  if (!text || typeof text !== 'string') return null;
  const toks = tokenize(text);
  // phrases (contiguous token sequences); also try with Arabic particles stripped from first token
  for (const p of phrases) {
    const n = p.toks.length;
    for (let i = 0; i + n <= toks.length; i++) {
      let ok = true;
      for (let k = 0; k < n && ok; k++) {
        const a = toks[i + k], b = p.toks[k];
        ok = a === b || (k === 0 && variants(a).has(b)) || (k === n - 1 && variants(a).has(b));
      }
      if (ok) return { category: p.category, term: p.toks.join(' ') };
    }
  }
  for (let i = 0; i < toks.length; i++) {
    for (const v of variants(toks[i])) {
      const e = singles.get(v);
      if (!e) continue;
      if (!e.d) return { category: e.category, term: v };
      // directed insult: walk back over fillers/copulas ("you are such an idiot", "you stupid idiot", "يا حمار", "انت غبي")
      for (let k = i - 1, steps = 0; k >= 0 && steps < 6; k--, steps++) {
        const tk = toks[k];
        if (ADDRESS.has(tk) || (tk.startsWith('يا') && tk.length < 6)) return { category: 'insult', term: v };
        if (!(FILLER.has(tk) || singles.get(tk)?.d)) break;
      }
      if (i === 0 && /^يا/.test(raw0(text))) return { category: 'insult', term: v };
    }
  }
  return null;
}
const raw0 = (t) => norm(t).trim();

module.exports = { check, loadExtra, norm, tokenize };
