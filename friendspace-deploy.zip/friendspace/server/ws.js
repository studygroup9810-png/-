'use strict';
// Minimal RFC 6455 WebSocket server (no dependencies).
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 64 * 1024;

class Conn extends EventEmitter {
  constructor(socket) {
    super();
    this.socket = socket; this.buf = Buffer.alloc(0); this.alive = true; this.closed = false;
    this.fragOp = 0; this.frags = []; this.fragSize = 0;
    socket.setNoDelay(true);
    socket.on('data', (c) => this._data(c));
    socket.on('close', () => this._end());
    socket.on('error', () => this._end());
  }
  _end() { if (this.closed) return; this.closed = true; this.emit('close'); }
  _frame(op, payload) {
    const len = payload.length; let h;
    if (len < 126) h = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
    return Buffer.concat([h, payload]);
  }
  _write(buf) {
    if (this.closed || !this.socket.writable) return;
    if (this.socket.writableLength > 4 * 1024 * 1024) { this.terminate(); return; }
    this.socket.write(buf);
  }
  send(text) { this._write(this._frame(0x1, Buffer.from(text, 'utf8'))); }
  ping() { this._write(this._frame(0x9, Buffer.alloc(0))); }
  close(code = 1000) {
    if (this.closed) return;
    const p = Buffer.alloc(2); p.writeUInt16BE(code, 0);
    this._write(this._frame(0x8, p));
    this.socket.end();
    setTimeout(() => this.socket.destroy(), 1000).unref();
  }
  terminate() { this.socket.destroy(); this._end(); }
  _fail(code) { this.close(code); }
  _data(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80);
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) {
        if (b.length < 10) return;
        const big = b.readBigUInt64BE(2);
        if (big > BigInt(MAX_PAYLOAD)) return this._fail(1009);
        len = Number(big); off = 10;
      }
      if (len > MAX_PAYLOAD) return this._fail(1009);
      if (!masked) return this._fail(1002);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4);
      const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (op >= 0x8) {
        if (!fin || len > 125) return this._fail(1002);
        if (op === 0x8) { this.close(1000); return; }
        if (op === 0x9) this._write(this._frame(0xA, payload));
        else if (op === 0xA) this.alive = true;
        continue;
      }
      if (op !== 0) { this.fragOp = op; this.frags = []; this.fragSize = 0; }
      else if (!this.fragOp) return this._fail(1002);
      this.frags.push(payload); this.fragSize += payload.length;
      if (this.fragSize > MAX_PAYLOAD) return this._fail(1009);
      if (fin) {
        const data = Buffer.concat(this.frags); const fop = this.fragOp;
        this.fragOp = 0; this.frags = []; this.fragSize = 0;
        if (fop === 0x1) this.emit('message', data.toString('utf8'));
      }
    }
  }
}

/** Completes the handshake and returns a Conn, or null (socket is destroyed). */
function accept(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if ((req.headers.upgrade || '').toLowerCase() !== 'websocket' || !key || req.headers['sec-websocket-version'] !== '13') {
    socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return null;
  }
  const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  return new Conn(socket);
}

module.exports = { accept };
